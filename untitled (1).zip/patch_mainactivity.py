import os

path = 'app/src/main/java/com/example/MainActivity.kt'
with open(path, 'r') as f:
    text = f.read()

# I will find the `onNewChat = { chatViewModel.startNewChat() }` and replace it
# with `onNewChat = { chatViewModel.startNewChat() },\n    onUpdateMessage = { id, liked, disliked, reported -> chatViewModel.updateMessageState(id, liked, disliked, reported) }`

if "onNewChat = { chatViewModel.startNewChat() }" in text:
    if "onUpdateMessage =" not in text:
        text = text.replace("onNewChat = { chatViewModel.startNewChat() }", "onNewChat = { chatViewModel.startNewChat() },\n                                onUpdateMessage = { id, liked, disliked, reported ->\n                                    chatViewModel.updateMessageState(id, liked, disliked, reported)\n                                }")
        with open(path, 'w') as f:
            f.write(text)
        print("MainActivity patched.")
    else:
        print("Already patched.")
else:
    print("Could not find onNewChat")
