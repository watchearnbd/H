import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
with open(path, 'r') as f:
    text = f.read()

# Relax thresholds slightly for typo and chapter/verse
text = text.replace('bestScore >= 0.85 -> MatchResult(bestMatch, MatchConfidence.HIGH)',
                    'bestScore >= 0.80 -> MatchResult(bestMatch, MatchConfidence.HIGH)')

# In the Chapter and verse parsing section, ensure we give enough score
text = text.replace('maxScore = maxOf(maxScore, 0.92)', 'maxScore = maxOf(maxScore, 0.95)')

with open(path, 'w') as f:
    f.write(text)
print("SmartKnowledgeMatcher thresholds relaxed.")
