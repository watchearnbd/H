package com.example.ai

import com.example.data.KnowledgeEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartKnowledgeMatcherTest {

    private val knowledgeBase = listOf(
        KnowledgeEntity(
            title = "গায়ত্রী মন্ত্র",
            category = "Mantra",
            subcategory = "Vedic",
            scripture = "ঋগ্বেদ",
            reference = "৩.৬২.১০",
            tags = "গায়ত্রী মন্ত্র, Gayatri Mantra, गायत्री मंत्र, সূর্য, বৈদিক, প্রার্থনা, গায়ত্রী, গায়েত্রী",
            content = "ওঁ ভূর্ভুবঃ স্বঃ...",
            explanation = "এটি অন্যতম পবিত্র বৈদিক মন্ত্র।",
            source = "Local",
            verifiedStatus = "Verified"
        ),
        KnowledgeEntity(
            title = "মহামৃত্যুঞ্জয় মন্ত্র",
            category = "Mantra",
            subcategory = "Shiva",
            scripture = "ঋগ্বেদ",
            reference = "৭.৫৯.১২",
            tags = "মহামৃত্যুঞ্জয় মন্ত্র, Mahamrityunjaya Mantra, महामृत्युंजय मंत्र, শিব, মহাদেব, ত্র্যম্বক, Shiva Mantra",
            content = "ওঁ ত্র্যম্বকং যজামহে...",
            explanation = "এটি ভগবান শিবের একটি অত্যন্ত শক্তিশালী মন্ত্র।",
            source = "Local",
            verifiedStatus = "Verified"
        ),
        KnowledgeEntity(
            title = "কর্মযোগ (নিষ্কাম কর্ম)",
            category = "Bhagavad Gita",
            scripture = "ভগবদ্গীতা",
            reference = "অধ্যায় ২, শ্লোক ৪৭",
            tags = "কর্মযোগ, কর্ম, গীতা, নিষ্কাম কর্ম, দায়িত্ব, Karma, Bhagavad Gita, ভগবদ গীতা, Gita",
            content = "কর্মণ্যেवाधिकारस्ते...",
            explanation = "কর্মে তোমার অধিকার আছে...",
            source = "Local",
            verifiedStatus = "Verified"
        )
    )

    @Test
    fun testExactMatch() {
        val result = SmartKnowledgeMatcher.match("গায়ত্রী মন্ত্র", knowledgeBase)
        assertEquals(MatchConfidence.HIGH, result.confidence)
        assertEquals("গায়ত্রী মন্ত্র", result.entity?.title)
    }

    @Test
    fun testAliasMatch() {
        val result1 = SmartKnowledgeMatcher.match("Gayatri Mantra", knowledgeBase)
        assertEquals(MatchConfidence.HIGH, result1.confidence)
        
        val result2 = SmartKnowledgeMatcher.match("গায়েত্রী", knowledgeBase)
        assertEquals(MatchConfidence.HIGH, result2.confidence) // High due to alias
    }

    @Test
    fun testTypoMatch() {
        val result = SmartKnowledgeMatcher.match("মহামৃতুঞ্জয়", knowledgeBase)
        assertTrue(result.confidence == MatchConfidence.HIGH || result.confidence == MatchConfidence.MEDIUM)
        assertEquals("মহামৃত্যুঞ্জয় মন্ত্র", result.entity?.title)
    }

    @Test
    fun testScriptureAlias() {
        val result1 = SmartKnowledgeMatcher.match("ভগবদ গীতা", knowledgeBase)
        assertTrue(result1.confidence == MatchConfidence.HIGH)
        
        val result2 = SmartKnowledgeMatcher.match("Bhagavad Gita", knowledgeBase)
        assertTrue(result2.confidence == MatchConfidence.HIGH)
    }

    @Test
    fun testChapterVerse() {
        val result = SmartKnowledgeMatcher.match("গীতার ২ নম্বর অধ্যায়", knowledgeBase)
        assertTrue(result.confidence == MatchConfidence.HIGH)
        assertEquals("কর্মযোগ (নিষ্কাম কর্ম)", result.entity?.title)
    }

    @Test
    fun testAmbiguousOrUnknown() {
        val result1 = SmartKnowledgeMatcher.match("শক্তি", knowledgeBase)
        assertTrue(result1.confidence == MatchConfidence.LOW || result1.confidence == MatchConfidence.NONE)
        
        val result2 = SmartKnowledgeMatcher.match("asdfgh123", knowledgeBase)
        assertEquals(MatchConfidence.LOW, result2.confidence)
    }
}
