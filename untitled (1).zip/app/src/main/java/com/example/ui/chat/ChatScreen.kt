package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send

import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.buildAnnotatedString
import android.widget.Toast
import android.content.Intent

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.ChatMessage
import com.example.research.VerificationStatus
import com.example.research.SourceMetadata
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel, 
    showSources: Boolean = true,
    showScriptureSource: Boolean = true,
    showVerificationBadge: Boolean = true,
    textSize: String = "Medium",
    savedItemIds: Set<String> = emptySet(),
    onSaveMessage: (ChatMessage) -> Unit = {},
    onNewChat: () -> Unit = {},
    onUpdateMessage: (String, Boolean, Boolean, Boolean) -> Unit = { _, _, _, _ -> }
) {
    
    val context = LocalContext.current
    var playingMessageId by remember { mutableStateOf<String?>(null) }
    val ttsManager = remember { TtsManager(context) {} }
    DisposableEffect(Unit) {
        onDispose { ttsManager.shutdown() }
    }

    val messages by viewModel.messages.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val isDeepResearch by viewModel.isDeepResearch.collectAsState()

    var inputText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "DHARMA AI",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Hindu Scripture & Knowledge Base",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 0.5.sp
                )
            }
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onNewChat, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Chat",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                
                Text(
                    text = if (isDeepResearch) "🔎 Deep" else "⚡ Fast", 
                    fontSize = 11.sp, 
                    fontWeight = FontWeight.Bold,
                    color = if (isDeepResearch) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(end = 4.dp)
                )
                Switch(
                    checked = isDeepResearch,
                    onCheckedChange = { viewModel.toggleDeepResearch(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                        checkedTrackColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.scale(0.8f)
                )
            }
        }

        // Chat Area
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(messages) { message ->
                ChatMessageItem(
                    message = message, 
                    showSources = showSources,
                    showScriptureSource = showScriptureSource,
                    showVerificationBadge = showVerificationBadge,
                    textSize = textSize,
                    isSaved = savedItemIds.contains(message.id),
                    onSaveClick = { onSaveMessage(message) },
                    onSuggestionClick = { suggestion -> inputText = suggestion }
                )
            }

            if (uiState is ChatUiState.Loading) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .border(1.dp, MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = MaterialTheme.colorScheme.primary,
                                strokeWidth = 2.dp
                            )
                            Text(
                                text = (uiState as ChatUiState.Loading).progressMessage, 
                                fontSize = 12.sp, 
                                fontWeight = FontWeight.Medium, 
                                color = Color(0xFF9A3412)
                            )
                        }
                    }
                }
            }
            
            if (uiState is ChatUiState.Error) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Error: ${(uiState as ChatUiState.Error).message}",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Input Area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .border(width = 1.dp, color = MaterialTheme.colorScheme.primaryContainer)
                .padding(16.dp)
                .padding(bottom = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    textStyle = TextStyle(color = EditorialSlate900, fontSize = 14.sp),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    decorationBox = { innerTextField ->
                        if (inputText.isEmpty()) {
                            Text("Ask about scriptures...", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                        }
                        innerTextField()
                    }
                )
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank() && uiState !is ChatUiState.Loading) {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                }
            }
            
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, start = 4.dp, end = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("RESEARCH", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.5.sp, modifier = Modifier.background(EditorialSlate100, RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 4.dp))
                    Text("PHASE 2", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.5.sp, modifier = Modifier.background(EditorialSlate100, RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 4.dp))
                }
                TextButton(
                    onClick = { viewModel.retry() },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Retry Engine", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, textDecoration = TextDecoration.Underline)
                }
        }
    }
}
}



@Composable
fun ChatMessageItem(
    message: ChatMessage, 
    showSources: Boolean = true,
    showVerificationBadge: Boolean = true,
    showScriptureSource: Boolean = true,
    textSize: String = "Medium",
    isSaved: Boolean = false,
    onSaveClick: () -> Unit = {},
    onSuggestionClick: (String) -> Unit = {},
    isPlaying: Boolean = false,
    onPlayClick: () -> Unit = {},
    onActionClick: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var showFeedbackDialog by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }

    if (showFeedbackDialog) {
        AlertDialog(
            onDismissRequest = { showFeedbackDialog = false },
            title = { Text("মতামত দিন") },
            text = { Text("এই উত্তরটি কেন ভালো লাগেনি?") },
            confirmButton = {
                TextButton(onClick = { 
                    showFeedbackDialog = false 
                    onActionClick("dislike")
                }) { Text("জমা দিন") }
            },
            dismissButton = {
                TextButton(onClick = { showFeedbackDialog = false }) { Text("বাতিল") }
            }
        )
    }

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("রিপোর্ট করুন") },
            text = { Text("এই উত্তরে কি কোনো ভুল তথ্য বা সমস্যা আছে?") },
            confirmButton = {
                TextButton(onClick = { 
                    showReportDialog = false 
                    onActionClick("report")
                    Toast.makeText(context, "আপনার রিপোর্ট গ্রহণ করা হয়েছে। ধন্যবাদ।", Toast.LENGTH_SHORT).show()
                }) { Text("রিপোর্ট জমা দিন") }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) { Text("বাতিল") }
            }
        )
    }

    val dynamicFontSize = when (textSize) {
        "Small" -> 12.sp
        "Large" -> 18.sp
        else -> 14.sp
    }
    
    val dynamicLineHeight = when (textSize) {
        "Small" -> 18.sp
        "Large" -> 26.sp
        else -> 22.sp
    }
    
    if (message.isUser) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.End
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 0.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(text = message.text, color = Color.White, fontSize = dynamicFontSize, fontWeight = FontWeight.Medium, lineHeight = dynamicLineHeight)
            }
            Text("Just now", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp, end = 4.dp))
        }
    } else {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clip(RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Text("AI RESPONSE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.weight(1f))
                }
                
                Text(
                    text = message.text,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = dynamicFontSize,
                    lineHeight = dynamicLineHeight,
                    fontFamily = FontFamily.Serif
                )
                
                if (showSources) {
                    if (showVerificationBadge && message.verificationStatus != VerificationStatus.NONE) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🔎 Verification: ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                            val (statusText, statusColor) = when (message.verificationStatus) {
                                VerificationStatus.VERIFIED -> "✅ Verified" to MaterialTheme.colorScheme.primary
                                VerificationStatus.PARTIALLY_VERIFIED -> "⚠️ Partially Verified" to MaterialTheme.colorScheme.tertiary
                                VerificationStatus.NOT_VERIFIED -> "❓ Not Verified" to MaterialTheme.colorScheme.error
                                else -> "" to Color.Transparent
                            }
                            Text(statusText, fontSize = 11.sp, color = statusColor, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    if (showScriptureSource && message.sourceMetadata.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("📚 Sources:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                        message.sourceMetadata.forEach { src ->
                            val icon = if (src.sourceType.contains("web", ignoreCase = true)) "🌐" else "📜"
                            Text(
                                text = "$icon ${src.title} - ${src.reference}\n   (${src.sourceType})", 
                                fontSize = 11.sp, 
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            Text(
                                text = "Status: ${src.verificationStatus.name.replace("_", " ")}",
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(start = 16.dp)
                            )
                        }
                    }
                    
                    if (message.youtubeSources.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("▶️ Related Videos:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                        val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                        
                        message.youtubeSources.forEach { y ->
                            Column(
                                modifier = Modifier
                                    .padding(top = 8.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(12.dp)
                            ) {
                                Text(y.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                Text(y.channelTitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
                                
                                androidx.compose.material3.TextButton(
                                    onClick = { uriHandler.openUri("https://www.youtube.com/watch?v=${y.videoId}") },
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.height(24.dp)
                                ) {
                                    Text("▶️ Watch on YouTube", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onPlayClick, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = "Voice",
                                    tint = if (isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(onClick = {
                                clipboardManager.setText(buildAnnotatedString { append(message.text) })
                                Toast.makeText(context, "উত্তরটি কপি হয়েছে ✓", Toast.LENGTH_SHORT).show()
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(onClick = {
                                val sendIntent: Intent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "Dharma AI\nAI উত্তর:\n${message.text}")
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, null)
                                context.startActivity(shareIntent)
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Share",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { onActionClick("like") }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (message.isLiked) Icons.Default.ThumbUp else Icons.Outlined.ThumbUp,
                                    contentDescription = "Like",
                                    tint = if (message.isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(onClick = {
                                if (message.isDisliked) onActionClick("dislike") else showFeedbackDialog = true
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (message.isDisliked) Icons.Default.ThumbDown else Icons.Outlined.ThumbDown,
                                    contentDescription = "Dislike",
                                    tint = if (message.isDisliked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(onClick = {
                                if (message.isReported) return@IconButton else showReportDialog = true
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (message.isReported) Icons.Default.Flag else Icons.Outlined.Flag,
                                    contentDescription = "Report",
                                    tint = if (message.isReported) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            androidx.compose.material3.TextButton(
                                onClick = onSaveClick,
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text(
                                    text = if (isSaved) "⭐ Saved" else "🔖 Save",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSaved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                
                if (message.suggestedQuestions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("💡 Suggested Follow-ups:", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        message.suggestedQuestions.forEach { suggestion ->
                            Surface(
                                onClick = { onSuggestionClick(suggestion) },
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = suggestion,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "Send",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

