package com.example.ui.chat

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

class TtsManager(context: Context, private val onInitCompleted: (Boolean) -> Unit) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    var isInitialized = false
    private var onCompletionListener: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context, this)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                onCompletionListener?.invoke()
            }

            override fun onError(utteranceId: String?) {
                onCompletionListener?.invoke()
            }
        })
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            onInitCompleted(true)
        } else {
            Log.e("TtsManager", "Initialization Failed!")
            onInitCompleted(false)
        }
    }

    fun speak(text: String, isBengali: Boolean, speed: Float, onCompletion: () -> Unit) {
        if (!isInitialized || tts == null) {
            onCompletion()
            return
        }
        
        onCompletionListener = onCompletion
        
        // Always try to use the best locale available
        val primaryLocale = if (isBengali) Locale("bn", "BD") else Locale.US
        val secondaryLocale = if (isBengali) Locale("bn") else Locale.UK
        
        var result = tts?.setLanguage(primaryLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            result = tts?.setLanguage(secondaryLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TtsManager", "Language not supported")
                onCompletion() // Cannot speak
                return
            }
        }
        
        tts?.setSpeechRate(speed)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "TTS_ID_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
        onCompletionListener?.invoke()
        onCompletionListener = null
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
