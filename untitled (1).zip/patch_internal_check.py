import os
import re

ade_path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(ade_path, 'r') as f:
    text = f.read()

# We need to rewrite AdvancedDecisionEngine.kt completely to inject the two-step process securely.
new_code = """package com.example.ai

import com.example.research.ILocalKnowledgeProvider
import com.example.data.KnowledgeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AdvancedDecisionEngine(
    private val localKnowledgeProvider: ILocalKnowledgeProvider,
    private val aiProvider: AiProvider
) {
    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {
        
        onProgress("Context বিশ্লেষণ করছি...")
        
        // 1. Search Local Knowledge
        val keywords = userMessage.split(Regex("\\\\s+")).filter { it.length > 2 }
        var results = localKnowledgeProvider.search(userMessage)
        if (results.isEmpty() && keywords.isNotEmpty()) {
            val kwResults = mutableListOf<KnowledgeEntity>()
            for (keyword in keywords) {
                kwResults.addAll(localKnowledgeProvider.search(keyword))
            }
            results = kwResults.distinctBy { it.id }.take(3)
        }

        // Prepare Local Knowledge Context for Gemini
        val localContextBuilder = java.lang.StringBuilder()
        if (results.isNotEmpty()) {
            results.forEach {
                localContextBuilder.append("Title: ${it.title}\\n")
                localContextBuilder.append("Scripture: ${it.scripture} (${it.reference})\\n")
                if (it.sanskritText.isNotBlank()) localContextBuilder.append("Mantra/Shloka: ${it.sanskritText}\\n")
                if (it.banglaMeaning.isNotBlank()) localContextBuilder.append("Meaning: ${it.banglaMeaning}\\n")
                if (it.content.isNotBlank()) localContextBuilder.append("Details: ${it.content}\\n")
                if (it.explanation.isNotBlank()) localContextBuilder.append("Explanation: ${it.explanation}\\n\\n")
            }
        } else {
            localContextBuilder.append("[EMPTY]\\n")
        }

        val systemPrompt = ""\"
            You are Dharma AI, a natural, friendly conversational assistant.
            
            Your behavior must strictly follow these rules:
            1. CASUAL CONVERSATION: 
               - For greetings ("হাই", "হ্যালো", etc.), reply with a natural, friendly greeting (e.g., "নমস্কার! আমি Dharma AI. আপনাকে কীভাবে সাহায্য করতে পারি?").
               - For personal questions ("কেমন আছো?"), give a friendly, normal reply.
               - Do not give religious lectures for casual or irrelevant questions.
               
            2. CONTEXT AWARENESS & FOLLOW-UPS:
               - Analyze the chat history to understand pronouns like "এটা কী?", "কেন?", "এর মানে কী?".
               - If the user asks to simplify ("আরও সহজ করে বলো", "সহজ ভাষায় বোঝাও"), rewrite your *previous* answer in very simple, easy-to-understand Bengali.
               - If the user asks "কেন?", explain the reason based on the previous topic.
               
            3. CLARIFICATION:
               - If the user's question is unclear or ambiguous, DO NOT guess. Ask a short clarification question.
               
            4. FACTUAL QUESTIONS & LOCAL KNOWLEDGE (CRITICAL):
               - For any factual question about religion, scripture, history, concepts, etc., YOU MUST ONLY USE the "LOCAL KNOWLEDGE RESULTS" provided below.
               - If it is a FACTUAL question and the "LOCAL KNOWLEDGE RESULTS" is [EMPTY], YOU MUST NOT invent facts or use your pre-trained knowledge. You MUST reply exactly: "এই তথ্যটি আমার Verified Knowledge Base-এ নেই।"
               - Note: The "Verified Knowledge Base-এ নেই" rule ONLY applies to new factual questions. Do NOT use it for greetings, clarifications, or simplification/elaboration requests of already discussed topics.

            5. STRICT TRUTH-FIRST RULE (CRITICAL):
               - Your primary goal is "সঠিক ও নির্ভরযোগ্য উত্তর" (Accurate and reliable answer), NEVER "সুন্দর উত্তর" (beautiful but fake answer).
               - NEVER invent, hallucinate, or guess any Scripture name, Mantra, Shloka, Chapter, or Verse.
               - If the exact reference is not known or the LOCAL KNOWLEDGE is [EMPTY], DO NOT GUESS.
               - If different traditions (e.g., Vaishnava, Shaiva, Shakta) have differing opinions, state them neutrally without taking sides.
               - When quoting Mantras or Shlokas, you MUST include the Source and Verification Status.
               - NEVER present unverified or unknown information as a known fact.
               
            === LOCAL KNOWLEDGE RESULTS ===
            $localContextBuilder
            ===============================
        ""\".trimIndent()

        val apiHistory = history.map { 
            Content(role = if (it.isUser) "user" else "model", parts = listOf(Part(text = it.text))) 
        }.toMutableList()
        
        apiHistory.add(Content(role = "user", parts = listOf(Part(text = userMessage))))
        
        onProgress("উত্তর তৈরি করছি...")
        val draftResponse = try {
            aiProvider.generateResponse(apiHistory, systemPrompt)
        } catch (e: Exception) {
            "দুঃখিত, উত্তর তৈরি করতে সমস্যা হয়েছে: ${e.message}"
        }

        onProgress("Internal Response Check...")
        val finalResponseText = try {
            runInternalCheck(userMessage, draftResponse, localContextBuilder.toString(), aiProvider)
        } catch (e: Exception) {
            draftResponse // Fallback
        }

        // Extract Local Sources for the UI if we used them
        val sourcesList = mutableListOf<String>()
        if (results.isNotEmpty() && !finalResponseText.contains("Verified Knowledge Base-এ নেই")) {
            results.forEach { 
                val sourceStr = "${it.scripture} (${it.reference})".trim()
                if (sourceStr.length > 3) {
                    sourcesList.add(sourceStr)
                }
            }
        }

        return@withContext ChatMessage(
            isUser = false,
            text = finalResponseText,
            localSources = sourcesList.distinct(),
            verificationStatus = if (sourcesList.isNotEmpty()) com.example.research.VerificationStatus.VERIFIED else com.example.research.VerificationStatus.NONE
        )
    }

    private suspend fun runInternalCheck(
        userQuery: String,
        draftAnswer: String,
        localContext: String,
        aiProvider: AiProvider
    ): String {
        // Skip check if it's already admitting lack of knowledge or error
        if (draftAnswer.contains("Verified Knowledge Base-এ নেই") || draftAnswer.contains("দুঃখিত,")) {
            return draftAnswer
        }

        val checkerPrompt = ""\"
            You are the "Internal Quality & Truth Checker" for Dharma AI.
            You must evaluate a DRAFT ANSWER generated for the USER QUERY against the available LOCAL KNOWLEDGE.
            
            Evaluate the following 9 checklist points internally:
            1. What is the question?
            2. What is the context?
            3. Is the answer in Local Knowledge?
            4. Is the answer verified?
            5. Were any facts, scriptures, or mantras guessed?
            6. Are Scripture/Mantra references correct?
            7. Is the answer direct?
            8. Is there unnecessary fluff or lecturing?
            9. Is there any fake information?
            
            Based on this evaluation:
            - If there is ANY hallucinated fact, guessed scripture/mantra, or fake information NOT in Local Knowledge: REMOVE IT entirely.
            - If the DRAFT ANSWER claims something factual not supported by Local Knowledge, change the response to state uncertainty or "এই তথ্যটি আমার Verified Knowledge Base-এ নেই।"
            - If there is unnecessary lecturing or fluff, edit it down to be direct and natural.
            - DO NOT output the checklist evaluation steps.
            - OUTPUT ONLY the final, polished, truthful Bengali text that will be shown directly to the user.
            
            ---
            USER QUERY:
            $userQuery
            
            AVAILABLE LOCAL KNOWLEDGE:
            $localContext
            
            DRAFT ANSWER:
            $draftAnswer
            ---
            
            Final Corrected Output (in Bengali):
        ""\".trimIndent()

        val checkHistory = listOf(
            Content(role = "user", parts = listOf(Part(text = checkerPrompt)))
        )

        return aiProvider.generateResponse(checkHistory, null)
    }
}
"""

with open(ade_path, 'w') as f:
    f.write(new_code)

print("Patch applied.")
