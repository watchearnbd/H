import os

path = 'app/src/main/java/com/example/research/Providers.kt'
with open(path, 'r') as f:
    text = f.read()

bad_impl = """    override suspend fun search(query: String): List<KnowledgeEntity>
    suspend fun getAllKnowledge(): List<KnowledgeEntity> {
        return dao.searchKnowledge(query)
    }

    override suspend fun getAllKnowledge(): List<KnowledgeEntity> {
        return dao.getAllKnowledge()
    }"""

good_impl = """    override suspend fun search(query: String): List<KnowledgeEntity> {
        return dao.searchKnowledge(query)
    }

    override suspend fun getAllKnowledge(): List<KnowledgeEntity> {
        return dao.getAllKnowledge()
    }"""

text = text.replace(bad_impl, good_impl)

with open(path, 'w') as f:
    f.write(text)
print("Providers.kt patched.")
