import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
with open(path, 'r') as f:
    text = f.read()

new_code = """package com.example.ai

import com.example.data.KnowledgeEntity
import kotlin.math.max

enum class MatchConfidence {
    HIGH, MEDIUM, LOW, NONE
}

data class MatchResult(
    val entity: KnowledgeEntity?,
    val confidence: MatchConfidence,
    val requiresClarification: Boolean = false,
    val clarificationMessage: String = ""
)

object SmartKnowledgeMatcher {

    fun match(query: String, knowledgeBase: List<KnowledgeEntity>): MatchResult {
        val normalizedQuery = normalize(query)
        if (normalizedQuery.isBlank()) return MatchResult(null, MatchConfidence.NONE)

        var bestMatch: KnowledgeEntity? = null
        var bestScore = 0.0

        for (entity in knowledgeBase) {
            val score = calculateScore(normalizedQuery, entity)
            if (score > bestScore) {
                bestScore = score
                bestMatch = entity
            }
        }

        return when {
            bestScore >= 0.85 -> MatchResult(bestMatch, MatchConfidence.HIGH)
            bestScore >= 0.50 -> MatchResult(bestMatch, MatchConfidence.MEDIUM, true, "আপনি কি '${bestMatch?.title}' এর কথা বলছেন?")
            else -> MatchResult(null, MatchConfidence.LOW, true, "আপনি কোন বিষয়টি বা মন্ত্রটি বোঝাচ্ছেন একটু পরিষ্কার করে বলবেন? নামটা হয়তো একটু ভিন্নভাবে লেখা হয়েছে। 😊")
        }
    }

    private fun normalize(text: String): String {
        return text.lowercase()
            .replace(Regex("[\\p{Punct}]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
    
    private fun levenshteinRatio(s1: String, s2: String): Double {
        if (s1 == s2) return 1.0
        if (s1.isEmpty() || s2.isEmpty()) return 0.0
        val maxLen = maxOf(s1.length, s2.length).toDouble()
        
        var costs = IntArray(s2.length + 1) { it }
        var newCosts = IntArray(s2.length + 1)

        for (i in 0 until s1.length) {
            newCosts[0] = i + 1
            for (j in 0 until s2.length) {
                val match = if (s1[i] == s2[j]) 0 else 1
                val costReplace = costs[j] + match
                val costInsert = costs[j + 1] + 1
                val costDelete = newCosts[j] + 1
                newCosts[j + 1] = minOf(costInsert, costDelete, costReplace)
            }
            val swap = costs
            costs = newCosts
            newCosts = swap
        }
        val distance = costs[s2.length]
        return 1.0 - (distance / maxLen)
    }

    private fun calculateScore(normalizedQuery: String, entity: KnowledgeEntity): Double {
        val titleNorm = normalize(entity.title)
        val aliases = entity.tags.split(",").map { normalize(it) }

        // 1. Exact Title Match
        if (normalizedQuery == titleNorm) return 1.0

        // 2. Exact Alias Match
        if (aliases.any { it == normalizedQuery }) return 0.95
        
        var maxScore = 0.0

        // 3. String similarity (Fuzzy Match) for full strings
        maxScore = maxOf(maxScore, levenshteinRatio(normalizedQuery, titleNorm))
        
        for (alias in aliases) {
            maxScore = maxOf(maxScore, levenshteinRatio(normalizedQuery, alias) * 0.95)
            // Partial match logic (if query is part of alias or vice versa, but long enough)
            if (alias.contains(normalizedQuery) || normalizedQuery.contains(alias)) {
                val ratio = minOf(alias.length, normalizedQuery.length).toDouble() / maxOf(alias.length, normalizedQuery.length)
                if (ratio > 0.5) maxScore = maxOf(maxScore, 0.70 + (ratio * 0.2))
            }
        }
        
        if (titleNorm.contains(normalizedQuery) || normalizedQuery.contains(titleNorm)) {
            val ratio = minOf(titleNorm.length, normalizedQuery.length).toDouble() / maxOf(titleNorm.length, normalizedQuery.length)
            if (ratio > 0.5) maxScore = maxOf(maxScore, 0.75 + (ratio * 0.2))
        }

        // Chapter and verse parsing for scriptures
        val scriptureNorm = normalize(entity.scripture)
        if (scriptureNorm.isNotBlank() && (normalizedQuery.contains(scriptureNorm) || (scriptureNorm.contains("গীতা") && normalizedQuery.contains("গীতা")) || (scriptureNorm.contains("gita") && normalizedQuery.contains("gita")))) {
            val numbers = Regex("\\d+").findAll(normalizedQuery).map { it.value }.toList()
            val entityRefNorm = normalize(entity.reference)
            val entityNumbers = Regex("\\d+").findAll(entityRefNorm).map { it.value }.toList()
            
            if (numbers.isNotEmpty() && entityNumbers.isNotEmpty()) {
                val intersection = numbers.intersect(entityNumbers.toSet())
                if (intersection.size == entityNumbers.size || (intersection.isNotEmpty() && numbers.size <= 2)) {
                    maxScore = maxOf(maxScore, 0.92)
                }
            } else if (normalizedQuery.contains(scriptureNorm)) {
               maxScore = maxOf(maxScore, 0.6)
            }
        }

        // 4. Fuzzy Token Matching
        val queryTokens = normalizedQuery.split(" ").filter { it.length > 2 }
        if (queryTokens.isNotEmpty()) {
            val titleTokens = titleNorm.split(" ")
            
            var matchedTokens = 0.0
            for (token in queryTokens) {
                var bestTokenMatch = 0.0
                
                // Compare with title tokens
                for (tToken in titleTokens) {
                    bestTokenMatch = maxOf(bestTokenMatch, levenshteinRatio(token, tToken))
                }
                
                // Compare with alias tokens
                for (alias in aliases) {
                    for (aToken in alias.split(" ")) {
                        bestTokenMatch = maxOf(bestTokenMatch, levenshteinRatio(token, aToken) * 0.9)
                    }
                }
                
                if (bestTokenMatch > 0.75) {
                    matchedTokens += bestTokenMatch
                }
            }
            
            val tokenScore = (matchedTokens / queryTokens.size) * 0.8 // Max 0.8
            maxScore = maxOf(maxScore, tokenScore)
        }

        return maxScore
    }
}
"""

with open(path, 'w') as f:
    f.write(new_code)
print("SmartKnowledgeMatcher updated with Levenshtein fuzzy matching.")
