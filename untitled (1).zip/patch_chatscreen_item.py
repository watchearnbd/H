import os
import re

path = 'app/src/main/java/com/example/ui/chat/ChatScreen.kt'
with open(path, 'r') as f:
    text = f.read()

sig_old = """fun ChatMessageItem(
    message: ChatMessage, 
    showSources: Boolean = true,
    showVerificationBadge: Boolean = true,
    showScriptureSource: Boolean = true,
    textSize: String = "Medium",
    isSaved: Boolean = false,
    onSaveClick: () -> Unit = {},
    onSuggestionClick: (String) -> Unit = {}
) {"""

sig_new = """fun ChatMessageItem(
    message: ChatMessage, 
    showSources: Boolean = true,
    showVerificationBadge: Boolean = true,
    showScriptureSource: Boolean = true,
    textSize: String = "Medium",
    isSaved: Boolean = false,
    onSaveClick: () -> Unit = {},
    onSuggestionClick: (String) -> Unit = {},
    isPlaying: Boolean = false,
    onPlayClick: () -> Unit = {},
    onActionClick: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var showFeedbackDialog by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }

    if (showFeedbackDialog) {
        AlertDialog(
            onDismissRequest = { showFeedbackDialog = false },
            title = { Text("মতামত দিন") },
            text = { Text("এই উত্তরটি কেন ভালো লাগেনি?") },
            confirmButton = {
                TextButton(onClick = { 
                    showFeedbackDialog = false 
                    onActionClick("dislike")
                }) { Text("জমা দিন") }
            },
            dismissButton = {
                TextButton(onClick = { showFeedbackDialog = false }) { Text("বাতিল") }
            }
        )
    }

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("রিপোর্ট করুন") },
            text = { Text("এই উত্তরে কি কোনো ভুল তথ্য বা সমস্যা আছে?") },
            confirmButton = {
                TextButton(onClick = { 
                    showReportDialog = false 
                    onActionClick("report")
                    Toast.makeText(context, "আপনার রিপোর্ট গ্রহণ করা হয়েছে। ধন্যবাদ।", Toast.LENGTH_SHORT).show()
                }) { Text("রিপোর্ট জমা দিন") }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) { Text("বাতিল") }
            }
        )
    }
"""

if sig_old in text:
    text = text.replace(sig_old, sig_new)
    with open(path, 'w') as f:
        f.write(text)
    print("ChatMessageItem signature patched.")
else:
    print("Could not find sig_old in ChatScreen.kt.")

