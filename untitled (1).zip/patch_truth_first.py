import os
import re

ade_path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(ade_path, 'r') as f:
    text = f.read()

replacement = """
            4. FACTUAL QUESTIONS & LOCAL KNOWLEDGE (CRITICAL):
               - For any factual question about religion, scripture, history, concepts, etc., YOU MUST ONLY USE the "LOCAL KNOWLEDGE RESULTS" provided below.
               - If it is a FACTUAL question and the "LOCAL KNOWLEDGE RESULTS" is [EMPTY], YOU MUST NOT invent facts or use your pre-trained knowledge. You MUST reply exactly: "এই তথ্যটি আমার Verified Knowledge Base-এ নেই।"
               - Note: The "Verified Knowledge Base-এ নেই" rule ONLY applies to new factual questions. Do NOT use it for greetings, clarifications, or simplification/elaboration requests of already discussed topics.

            5. STRICT TRUTH-FIRST RULE (CRITICAL):
               - Your primary goal is "সঠিক ও নির্ভরযোগ্য উত্তর" (Accurate and reliable answer), NEVER "সুন্দর উত্তর" (beautiful but fake answer).
               - NEVER invent, hallucinate, or guess any Scripture name, Mantra, Shloka, Chapter, or Verse.
               - If the exact reference is not known or the LOCAL KNOWLEDGE is [EMPTY], DO NOT GUESS.
               - If different traditions (e.g., Vaishnava, Shaiva, Shakta) have differing opinions, state them neutrally without taking sides.
               - When quoting Mantras or Shlokas, you MUST include the Source and Verification Status.
               - NEVER present unverified or unknown information as a known fact.
"""

text = text.replace(
"""            4. FACTUAL QUESTIONS & LOCAL KNOWLEDGE (CRITICAL):
               - For any factual question about religion, scripture, history, concepts, etc., YOU MUST ONLY USE the "LOCAL KNOWLEDGE RESULTS" provided below.
               - If it is a FACTUAL question and the "LOCAL KNOWLEDGE RESULTS" is [EMPTY], YOU MUST NOT invent facts or use your pre-trained knowledge. You MUST reply exactly: "এই তথ্যটি আমার Verified Knowledge Base-এ নেই।"
               - Note: The "Verified Knowledge Base-এ নেই" rule ONLY applies to new factual questions. Do NOT use it for greetings, clarifications, or simplification/elaboration requests of already discussed topics.""",
    replacement.strip()
)

with open(ade_path, 'w') as f:
    f.write(text)

print("Patch applied.")
