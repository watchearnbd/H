import os
import re

path = 'app/src/main/java/com/example/ui/chat/ChatScreen.kt'
with open(path, 'r') as f:
    text = f.read()

# Add imports
imports = """
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.buildAnnotatedString
import android.widget.Toast
import android.content.Intent
"""

text = text.replace("import androidx.compose.material.icons.filled.Add", imports)

# Update ChatScreen signature and add TTS manager
# Search for `fun ChatScreen(`
# Need to add `onUpdateMessage: (String, Boolean, Boolean, Boolean) -> Unit = {_,_,_,_},`
if "onUpdateMessage: (String, Boolean, Boolean, Boolean) -> Unit = {_,_,_,_}" not in text:
    text = text.replace("onNewChat: () -> Unit = {}", "onNewChat: () -> Unit = {},\n    onUpdateMessage: (String, Boolean, Boolean, Boolean) -> Unit = {_,_,_,_}")

# Add TTS Manager inside ChatScreen
tts_init = """
    val context = LocalContext.current
    var playingMessageId by remember { mutableStateOf<String?>(null) }
    val ttsManager = remember { TtsManager(context) {} }
    DisposableEffect(Unit) {
        onDispose { ttsManager.shutdown() }
    }
"""

if "val ttsManager = remember" not in text:
    text = text.replace("val messages by viewModel.messages.collectAsState()", tts_init + "\n    val messages by viewModel.messages.collectAsState()")

# Update ChatMessageItem call
# Search for `ChatMessageItem(`
call_old = """                ChatMessageItem(
                    message = message, 
                    showSources = showSources,
                    showScriptureSource = showScriptureSource,
                    showVerificationBadge = showVerificationBadge,
                    textSize = textSize,
                    isSaved = savedItemIds.contains(message.id),
                    onSaveClick = { onSaveMessage(message) },
                    onSuggestionClick = { suggestion -> 
                        inputText = suggestion
                        viewModel.sendMessage(suggestion)
                        inputText = ""
                    }
                )"""

call_new = """                ChatMessageItem(
                    message = message, 
                    showSources = showSources,
                    showScriptureSource = showScriptureSource,
                    showVerificationBadge = showVerificationBadge,
                    textSize = textSize,
                    isSaved = savedItemIds.contains(message.id),
                    onSaveClick = { onSaveMessage(message) },
                    onSuggestionClick = { suggestion -> 
                        inputText = suggestion
                        viewModel.sendMessage(suggestion)
                        inputText = ""
                    },
                    isPlaying = playingMessageId == message.id,
                    onPlayClick = {
                        if (playingMessageId == message.id) {
                            ttsManager.stop()
                            playingMessageId = null
                        } else {
                            ttsManager.stop()
                            playingMessageId = message.id
                            // 1.0f speed default, can be connected to settings later
                            val isBengali = message.text.any { it in '\\u0980'..'\\u09FF' }
                            ttsManager.speak(message.text, isBengali, 1.0f) {
                                playingMessageId = null
                            }
                        }
                    },
                    onActionClick = { action ->
                        when (action) {
                            "like" -> onUpdateMessage(message.id, !message.isLiked, false, message.isReported)
                            "dislike" -> onUpdateMessage(message.id, false, !message.isDisliked, message.isReported)
                            "report" -> onUpdateMessage(message.id, message.isLiked, message.isDisliked, true)
                        }
                    }
                )"""

if "isPlaying = playingMessageId" not in text:
    text = text.replace(call_old, call_new)

# Update ChatMessageItem signature
if "isPlaying: Boolean = false" not in text:
    sig_old = """fun ChatMessageItem(
    message: ChatMessage, 
    showSources: Boolean,
    showScriptureSource: Boolean,
    showVerificationBadge: Boolean,
    textSize: String,
    isSaved: Boolean,
    onSaveClick: () -> Unit,
    onSuggestionClick: (String) -> Unit
) {"""

    sig_new = """fun ChatMessageItem(
    message: ChatMessage, 
    showSources: Boolean,
    showScriptureSource: Boolean,
    showVerificationBadge: Boolean,
    textSize: String,
    isSaved: Boolean,
    onSaveClick: () -> Unit,
    onSuggestionClick: (String) -> Unit,
    isPlaying: Boolean = false,
    onPlayClick: () -> Unit = {},
    onActionClick: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var showFeedbackDialog by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }

    if (showFeedbackDialog) {
        AlertDialog(
            onDismissRequest = { showFeedbackDialog = false },
            title = { Text("মতামত দিন") },
            text = { Text("এই উত্তরটি কেন ভালো লাগেনি?") },
            confirmButton = {
                TextButton(onClick = { 
                    showFeedbackDialog = false 
                    onActionClick("dislike")
                }) { Text("জমা দিন") }
            },
            dismissButton = {
                TextButton(onClick = { showFeedbackDialog = false }) { Text("বাতিল") }
            }
        )
    }

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("রিপোর্ট করুন") },
            text = { Text("এই উত্তরে কি কোনো ভুল তথ্য বা সমস্যা আছে?") },
            confirmButton = {
                TextButton(onClick = { 
                    showReportDialog = false 
                    onActionClick("report")
                    Toast.makeText(context, "আপনার রিপোর্ট গ্রহণ করা হয়েছে। ধন্যবাদ।", Toast.LENGTH_SHORT).show()
                }) { Text("রিপোর্ট জমা দিন") }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) { Text("বাতিল") }
            }
        )
    }
"""
    text = text.replace(sig_old, sig_new)

# Replace the Action Row
row_old = """                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.TextButton(
                            onClick = onSaveClick,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text(
                                text = if (isSaved) "⭐ Saved" else "🔖 Save",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSaved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }"""

row_new = """                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onPlayClick, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = "Voice",
                                    tint = if (isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(onClick = {
                                clipboardManager.setText(buildAnnotatedString { append(message.text) })
                                Toast.makeText(context, "উত্তরটি কপি হয়েছে ✓", Toast.LENGTH_SHORT).show()
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(onClick = {
                                val sendIntent: Intent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "Dharma AI\\nAI উত্তর:\\n${message.text}")
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, null)
                                context.startActivity(shareIntent)
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Share",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { onActionClick("like") }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (message.isLiked) Icons.Default.ThumbUp else Icons.Outlined.ThumbUp,
                                    contentDescription = "Like",
                                    tint = if (message.isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(onClick = {
                                if (message.isDisliked) onActionClick("dislike") else showFeedbackDialog = true
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (message.isDisliked) Icons.Default.ThumbDown else Icons.Outlined.ThumbDown,
                                    contentDescription = "Dislike",
                                    tint = if (message.isDisliked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(onClick = {
                                if (message.isReported) return@IconButton else showReportDialog = true
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (message.isReported) Icons.Default.Flag else Icons.Outlined.Flag,
                                    contentDescription = "Report",
                                    tint = if (message.isReported) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            androidx.compose.material3.TextButton(
                                onClick = onSaveClick,
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text(
                                    text = if (isSaved) "⭐ Saved" else "🔖 Save",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSaved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }"""

if row_old in text:
    text = text.replace(row_old, row_new)

with open(path, 'w') as f:
    f.write(text)

print("ChatScreen patched.")
