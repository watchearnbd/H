import os
import re

ade_path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(ade_path, 'w') as f:
    f.write("""package com.example.ai

import com.example.research.ILocalKnowledgeProvider
import com.example.data.KnowledgeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AdvancedDecisionEngine(
    private val localKnowledgeProvider: ILocalKnowledgeProvider,
    private val aiProvider: AiProvider
) {
    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {
        
        onProgress("Context বিশ্লেষণ করছি...")
        
        // 1. Search Local Knowledge
        val keywords = userMessage.split(Regex("\\\\s+")).filter { it.length > 2 }
        var results = localKnowledgeProvider.search(userMessage)
        if (results.isEmpty() && keywords.isNotEmpty()) {
            val kwResults = mutableListOf<KnowledgeEntity>()
            for (keyword in keywords) {
                kwResults.addAll(localKnowledgeProvider.search(keyword))
            }
            results = kwResults.distinctBy { it.id }.take(3)
        }

        // Prepare Local Knowledge Context for Gemini
        val localContextBuilder = java.lang.StringBuilder()
        if (results.isNotEmpty()) {
            results.forEach {
                localContextBuilder.append("Title: ${it.title}\\n")
                localContextBuilder.append("Scripture: ${it.scripture} (${it.reference})\\n")
                if (it.sanskritText.isNotBlank()) localContextBuilder.append("Mantra/Shloka: ${it.sanskritText}\\n")
                if (it.banglaMeaning.isNotBlank()) localContextBuilder.append("Meaning: ${it.banglaMeaning}\\n")
                if (it.content.isNotBlank()) localContextBuilder.append("Details: ${it.content}\\n")
                if (it.explanation.isNotBlank()) localContextBuilder.append("Explanation: ${it.explanation}\\n\\n")
            }
        } else {
            localContextBuilder.append("[EMPTY]\\n")
        }

        val systemPrompt = ""\"
            You are Dharma AI, a natural, friendly conversational assistant.
            
            Your behavior must strictly follow these rules:
            1. CASUAL CONVERSATION: 
               - For greetings ("হাই", "হ্যালো", etc.), reply with a natural, friendly greeting (e.g., "নমস্কার! আমি Dharma AI. আপনাকে কীভাবে সাহায্য করতে পারি?").
               - For personal questions ("কেমন আছো?"), give a friendly, normal reply.
               - Do not give religious lectures for casual or irrelevant questions.
               
            2. CONTEXT AWARENESS & FOLLOW-UPS:
               - Analyze the chat history to understand pronouns like "এটা কী?", "কেন?", "এর মানে কী?".
               - If the user asks to simplify ("আরও সহজ করে বলো", "সহজ ভাষায় বোঝাও"), rewrite your *previous* answer in very simple, easy-to-understand Bengali.
               - If the user asks "কেন?", explain the reason based on the previous topic.
               
            3. CLARIFICATION:
               - If the user's question is unclear or ambiguous, DO NOT guess. Ask a short clarification question (e.g., "আপনি কি ... সম্পর্কে জানতে চাইছেন?").
               
            4. FACTUAL QUESTIONS & LOCAL KNOWLEDGE (CRITICAL):
               - For any factual question about religion, scripture, history, concepts, etc., YOU MUST ONLY USE the "LOCAL KNOWLEDGE RESULTS" provided below.
               - If it is a FACTUAL question and the "LOCAL KNOWLEDGE RESULTS" is [EMPTY], YOU MUST NOT invent facts or use your pre-trained knowledge. You MUST reply exactly: "এই তথ্যটি আমার Verified Knowledge Base-এ নেই।"
               - Note: The "Verified Knowledge Base-এ নেই" rule ONLY applies to new factual questions. Do NOT use it for greetings, clarifications, or simplification/elaboration requests of already discussed topics.
               
            === LOCAL KNOWLEDGE RESULTS ===
            $localContextBuilder
            ===============================
        ""\".trimIndent()

        val apiHistory = history.map { 
            Content(role = if (it.isUser) "user" else "model", parts = listOf(Part(text = it.text))) 
        }.toMutableList()
        
        apiHistory.add(Content(role = "user", parts = listOf(Part(text = userMessage))))
        
        onProgress("উত্তর তৈরি করছি...")
        val responseText = try {
            aiProvider.generateResponse(apiHistory, systemPrompt)
        } catch (e: Exception) {
            "দুঃখিত, উত্তর তৈরি করতে সমস্যা হয়েছে: ${e.message}"
        }

        // Extract Local Sources for the UI if we used them
        val sourcesList = mutableListOf<String>()
        if (results.isNotEmpty() && !responseText.contains("Verified Knowledge Base-এ নেই")) {
            results.forEach { 
                val sourceStr = "${it.scripture} (${it.reference})".trim()
                if (sourceStr.length > 3) {
                    sourcesList.add(sourceStr)
                }
            }
        }

        return@withContext ChatMessage(
            isUser = false,
            text = responseText,
            localSources = sourcesList.distinct(),
            verificationStatus = if (sourcesList.isNotEmpty()) com.example.research.VerificationStatus.VERIFIED else com.example.research.VerificationStatus.NONE
        )
    }
}
"""
    # Replace ${...} correctly by avoiding python string template conflict
    f.write(content.replace("${", "${"))

# Let's use a simpler approach to write the file safely
