import re

with open("app/src/main/java/com/example/ui/chat/ChatScreen.kt", "r") as f:
    content = f.read()

youtube_ui = """                }
                
                if (message.youtubeSources.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("▶️ Related Videos:", fontSize = 11.sp, color = EditorialSlate500, fontWeight = FontWeight.Bold)
                    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                    
                    message.youtubeSources.forEach { y ->
                        Column(
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(EditorialSlate50)
                                .padding(12.dp)
                        ) {
                            Text(y.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EditorialSlate800)
                            Text(y.channelTitle, fontSize = 10.sp, color = EditorialSlate500, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
                            
                            androidx.compose.material3.TextButton(
                                onClick = { uriHandler.openUri("https://www.youtube.com/watch?v=${y.videoId}") },
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text("▶️ Watch on YouTube", fontSize = 11.sp, color = Color(0xFFC2410C), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
"""

content = content.replace("                }\n            }\n        }\n    }\n}", youtube_ui)

with open("app/src/main/java/com/example/ui/chat/ChatScreen.kt", "w") as f:
    f.write(content)

