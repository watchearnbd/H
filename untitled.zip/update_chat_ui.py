import re

with open("app/src/main/java/com/example/ui/chat/ChatScreen.kt", "r") as f:
    content = f.read()

content = content.replace('text = "$icon ${src.title} - ${src.reference}",', 'text = "$icon ${src.title} - ${src.reference}\\n   (${src.sourceType})",')

with open("app/src/main/java/com/example/ui/chat/ChatScreen.kt", "w") as f:
    f.write(content)

