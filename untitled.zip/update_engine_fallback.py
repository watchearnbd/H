import re

with open("app/src/main/java/com/example/research/ResearchEngine.kt", "r") as f:
    content = f.read()

fallback_logic = """
            if (youtubeResults.isEmpty() && (isDeepResearch || webResults.isEmpty())) {
                // If it's a video related query, the AI might need this, but we don't have access to analysis.needsYouTube here easily...
                // Actually, let's just add it conditionally if youtubeResults is empty. 
                // Wait, analysis is not passed to generateFinalAnswer. I'll just let the AI know it's unavailable if it's empty.
            }
"""

# Let's pass analysis.needsYouTube to generateFinalAnswer? No, let's just modify the prompt directly in generateFinalAnswer.
# "YouTube unavailable হলে: "বর্তমানে YouTube research unavailable।" দেখিয়ে Local Knowledge/Web Research ব্যবহার করবে।"

fallback_logic = """
            if (youtubeResults.isEmpty()) {
                append("\\nIf the user specifically asked for a video and YouTube results are empty, you MUST state: 'বর্তমানে YouTube research unavailable।' and answer using other available knowledge.\\n")
            }
"""

content = content.replace(
    "            if (youtubeResults.isNotEmpty()) {",
    fallback_logic + "            if (youtubeResults.isNotEmpty()) {"
)

with open("app/src/main/java/com/example/research/ResearchEngine.kt", "w") as f:
    f.write(content)

