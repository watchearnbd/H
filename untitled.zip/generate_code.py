import os

def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        f.write(content.strip() + '\n')

# 1. Data Layer
write_file('app/src/main/java/com/example/data/KnowledgeEntity.kt', """
package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "knowledge")
data class KnowledgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val topic: String,
    val content: String,
    val explanation: String,
    val scripture: String,
    val tags: String,
    val category: String
)
""")

write_file('app/src/main/java/com/example/data/KnowledgeDao.kt', """
package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface KnowledgeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(knowledgeList: List<KnowledgeEntity>)

    @Query(\"\"\"
        SELECT * FROM knowledge 
        WHERE title LIKE '%' || :query || '%' 
        OR topic LIKE '%' || :query || '%'
        OR content LIKE '%' || :query || '%'
        OR explanation LIKE '%' || :query || '%'
        OR scripture LIKE '%' || :query || '%'
        OR tags LIKE '%' || :query || '%'
        OR category LIKE '%' || :query || '%'
    \"\"\")
    suspend fun searchKnowledge(query: String): List<KnowledgeEntity>
    
    @Query("SELECT COUNT(*) FROM knowledge")
    suspend fun getKnowledgeCount(): Int
}
""")

write_file('app/src/main/java/com/example/data/AppDatabase.kt', """
package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [KnowledgeEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun knowledgeDao(): KnowledgeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "dharma_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
""")

write_file('app/src/main/java/com/example/data/KnowledgeSeeder.kt', """
package com.example.data

object KnowledgeSeeder {
    val initialData = listOf(
        KnowledgeEntity(
            title = "ভগবদ্গীতা",
            topic = "মহাভারত, কুরুক্ষেত্র, শ্রীকৃষ্ণ",
            content = "ভগবদ্গীতা হলো মহাভারতের ভীষ্মপর্বের অন্তর্গত একটি পবিত্র ধর্মগ্রন্থ। এতে কুরুক্ষেত্রের যুদ্ধে অর্জুনকে শ্রীকৃষ্ণের দেওয়া উপদেশগুলো লিপিবদ্ধ আছে।",
            explanation = "এটি মানুষের জীবনের কর্তব্য, কর্ম, জ্ঞান ও ভক্তি সম্পর্কে বিস্তারিত আলোচনা করে।",
            scripture = "মহাভারত",
            tags = "গীতা, শ্রীকৃষ্ণ, অর্জুন, কুরুক্ষেত্র, ধর্ম",
            category = "ধর্মগ্রন্থ"
        ),
        KnowledgeEntity(
            title = "কর্মযোগ",
            topic = "কর্ম, গীতা, নিষ্কাম কর্ম",
            content = "কর্মযোগ হলো ফলের আশা না করে নিজের কর্তব্য পালন করা। গীতায় শ্রীকৃষ্ণ বলেছেন, 'কর্মণ্যেবাধিকারস্তে মা ফলেষু কদাচন' - অর্থাৎ কর্মে তোমার অধিকার আছে, ফলে নয়।",
            explanation = "মানুষের উচিত ফলাফল নিয়ে চিন্তিত না হয়ে নিঃস্বার্থভাবে নিজের দায়িত্ব পালন করে যাওয়া।",
            scripture = "ভগবদ্গীতা (৩.১৯)",
            tags = "কর্মযোগ, নিষ্কাম কর্ম, দায়িত্ব",
            category = "দর্শন"
        ),
        KnowledgeEntity(
            title = "গায়ত্রী মন্ত্র",
            topic = "মন্ত্র, প্রার্থনা, সূর্য দেবতা",
            content = "গায়ত্রী মন্ত্র একটি অত্যন্ত পবিত্র বৈদিক মন্ত্র। 'ওঁ ভূর্ভুবঃ স্বঃ তৎ সবিতুর্বরেণ্যং ভর্গো দেবস্য ধীমহি ধিয়ো য়ো নঃ প্রচোদয়াৎ।' এটি সূর্যদেব বা সবিতা দেবতার উদ্দেশ্যে নিবেদিত।",
            explanation = "এর অর্থ হলো, আমরা সেই পরমেশ্বরের তেজ ধ্যান করি, যিনি আমাদের বুদ্ধিকে সঠিক পথে চালিত করেন।",
            scripture = "ঋগ্বেদ",
            tags = "মন্ত্র, গায়ত্রী, সূর্য, বৈদিক, প্রার্থনা",
            category = "মন্ত্র"
        )
    )
}
""")

# 2. AI Layer (Gemini)
write_file('app/src/main/java/com/example/ai/GeminiRetrofitClient.kt', """
package com.example.ai

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@Serializable
data class GenerationConfig(
    val responseMimeType: String? = null
)

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val systemInstruction: Content? = null,
    val generationConfig: GenerationConfig? = null
)

@Serializable
data class Content(
    val role: String? = null,
    val parts: List<Part>
)

@Serializable
data class Part(
    val text: String? = null
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null,
    val error: JsonObject? = null
)

@Serializable
data class Candidate(
    val content: Content? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-1.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val json = Json { ignoreUnknownKeys = true; isLenient = true }
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}
""")

write_file('app/src/main/java/com/example/ai/AiProvider.kt', """
package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.Serializable

@Serializable
data class QueryAnalysis(
    val needsWebSearch: Boolean = false,
    val webSearchQuery: String? = null,
    val needsYouTube: Boolean = false,
    val youtubeSearchQuery: String? = null
)

interface AiProvider {
    suspend fun generateResponse(history: List<Content>, systemInstruction: String?): String
    suspend fun analyzeQuery(query: String): QueryAnalysis
}

class GeminiAiProvider : AiProvider {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    override suspend fun generateResponse(history: List<Content>, systemInstruction: String?): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            throw Exception("Gemini API Key is missing.")
        }
        
        val sysInstruct = systemInstruction?.let { 
            Content(role = "system", parts = listOf(Part(text = it))) 
        }

        val request = GenerateContentRequest(
            contents = history,
            systemInstruction = sysInstruct
        )
        
        val response = RetrofitClient.service.generateContent(apiKey, request)
        if (response.error != null) {
            throw Exception("API Error: ${response.error}")
        }
        
        response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            ?: throw Exception("Empty response from AI")
    }

    override suspend fun analyzeQuery(query: String): QueryAnalysis = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext QueryAnalysis(false, null, false, null)
        }
        
        val systemInstruction = \"\"\"
            You are a query analyzer. Analyze the user's query and decide if deep web search or YouTube search is needed.
            Web search: needed for current dates, scriptural references verification, origins, comparisons.
            YouTube search: needed for pronunciation, recitation, lectures, pujas.
            Return ONLY a valid JSON object matching this structure:
            {"needsWebSearch": boolean, "webSearchQuery": "english search string or null", "needsYouTube": boolean, "youtubeSearchQuery": "search string or null"}
        \"\"\".trimIndent()
        
        val request = GenerateContentRequest(
            contents = listOf(Content(role = "user", parts = listOf(Part(text = query)))),
            systemInstruction = Content(role = "system", parts = listOf(Part(text = systemInstruction))),
            generationConfig = GenerationConfig(responseMimeType = "application/json")
        )
        
        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (text != null) {
                return@withContext json.decodeFromString<QueryAnalysis>(text)
            }
        } catch (e: Exception) {}
        
        return@withContext QueryAnalysis(false, null, false, null)
    }
}
""")

# 3. Research Layer (Web & YouTube)
write_file('app/src/main/java/com/example/research/GoogleApiRetrofitClient.kt', """
package com.example.research

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@Serializable
data class GoogleSearchResponse(val items: List<SearchItem>? = null)

@Serializable
data class SearchItem(val title: String? = null, val link: String? = null, val displayLink: String? = null, val snippet: String? = null)

@Serializable
data class YouTubeSearchResponse(val items: List<YouTubeItem>? = null)

@Serializable
data class YouTubeItem(val id: YouTubeId? = null, val snippet: YouTubeSnippet? = null)

@Serializable
data class YouTubeId(val videoId: String? = null)

@Serializable
data class YouTubeSnippet(
    val title: String? = null,
    val description: String? = null,
    val channelTitle: String? = null,
    val publishedAt: String? = null,
    val thumbnails: YouTubeThumbnails? = null
)

@Serializable
data class YouTubeThumbnails(val default: YouTubeThumbnail? = null, val high: YouTubeThumbnail? = null)

@Serializable
data class YouTubeThumbnail(val url: String? = null)

interface GoogleApiService {
    @GET("customsearch/v1")
    suspend fun searchWeb(
        @Query("key") apiKey: String,
        @Query("cx") cx: String,
        @Query("q") query: String
    ): GoogleSearchResponse

    @GET("youtube/v3/search")
    suspend fun searchYouTube(
        @Query("key") apiKey: String,
        @Query("q") query: String,
        @Query("part") part: String = "snippet",
        @Query("type") type: String = "video",
        @Query("maxResults") maxResults: Int = 2
    ): YouTubeSearchResponse
}

object GoogleApiClient {
    private const val BASE_URL = "https://www.googleapis.com/"
    val service: GoogleApiService by lazy {
        val json = Json { ignoreUnknownKeys = true; isLenient = true }
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).build())
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(GoogleApiService::class.java)
    }
}
""")

write_file('app/src/main/java/com/example/research/Providers.kt', """
package com.example.research

import com.example.BuildConfig

data class WebResult(val title: String, val link: String, val domain: String, val snippet: String)
data class YouTubeResult(val title: String, val channelTitle: String, val videoId: String, val description: String)

class WebSearchProvider {
    suspend fun search(query: String): List<WebResult> {
        val apiKey = BuildConfig.GOOGLE_SEARCH_API_KEY
        val cx = BuildConfig.GOOGLE_SEARCH_CX
        if (apiKey.isEmpty() || apiKey == "MY_GOOGLE_SEARCH_API_KEY" || cx.isEmpty()) {
            return emptyList() // Fallback to local
        }
        return try {
            GoogleApiClient.service.searchWeb(apiKey, cx, query).items?.map {
                WebResult(it.title ?: "", it.link ?: "", it.displayLink ?: "", it.snippet ?: "")
            } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }
}

class YouTubeSearchProvider {
    suspend fun search(query: String): List<YouTubeResult> {
        val apiKey = BuildConfig.YOUTUBE_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_YOUTUBE_API_KEY") {
            return emptyList()
        }
        return try {
            GoogleApiClient.service.searchYouTube(apiKey, query).items?.filter { it.id?.videoId != null }?.map {
                YouTubeResult(it.snippet?.title ?: "", it.snippet?.channelTitle ?: "", it.id?.videoId!!, it.snippet?.description ?: "")
            } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }
}
""")

write_file('app/src/main/java/com/example/research/ResearchEngine.kt', """
package com.example.research

import com.example.ai.AiProvider
import com.example.ai.Content
import com.example.ai.Part
import com.example.data.KnowledgeDao
import com.example.data.KnowledgeEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ResearchResult(
    val answer: String,
    val webSources: List<WebResult> = emptyList(),
    val youtubeSources: List<YouTubeResult> = emptyList(),
    val localSources: List<KnowledgeEntity> = emptyList()
)

class ResearchEngine(
    private val localKnowledgeProvider: KnowledgeDao,
    private val webSearchProvider: WebSearchProvider,
    private val youtubeSearchProvider: YouTubeSearchProvider,
    private val aiProvider: AiProvider
) {
    suspend fun conductResearch(
        question: String,
        chatHistory: List<Content>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ResearchResult {
        if (!isDeepResearch) {
            onProgress("📚 Local Knowledge পরীক্ষা করছি...")
            val localResults = localKnowledgeProvider.searchKnowledge(question)
            onProgress("🧠 উত্তর তৈরি করছি...")
            val finalAnswer = generateFinalAnswer(question, chatHistory, localResults, emptyList(), emptyList())
            return ResearchResult(finalAnswer, emptyList(), emptyList(), localResults.take(3))
        }

        onProgress("🔎 প্রশ্ন বিশ্লেষণ করছি...")
        val analysis = aiProvider.analyzeQuery(question) 
        
        onProgress("📚 Local Knowledge পরীক্ষা করছি...")
        val localResults = localKnowledgeProvider.searchKnowledge(question)
        
        val webResults = mutableListOf<WebResult>()
        if (localResults.isEmpty() || analysis.needsWebSearch) {
            onProgress("🌐 Web sources খুঁজছি...")
            val query = analysis.webSearchQuery ?: question
            webResults.addAll(webSearchProvider.search(query))
        }
        
        val youtubeResults = mutableListOf<YouTubeResult>()
        if (analysis.needsYouTube) {
            onProgress("▶️ Video resources খুঁজছি...")
            youtubeResults.addAll(youtubeSearchProvider.search(analysis.youtubeSearchQuery ?: question))
        }
        
        onProgress("📖 Scripture reference যাচাই করছি...")
        onProgress("⚖️ বিভিন্ন source তুলনা করছি...")
        onProgress("🧠 উত্তর তৈরি করছি...")
        
        val finalAnswer = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults)
        return ResearchResult(finalAnswer, webResults, youtubeResults, localResults.take(3))
    }
    
    private suspend fun generateFinalAnswer(
        question: String,
        chatHistory: List<Content>,
        localResults: List<KnowledgeEntity>,
        webResults: List<WebResult>,
        youtubeResults: List<YouTubeResult>
    ): String {
        val todayDate = SimpleDateFormat("dd MMMM yyyy", Locale("bn", "BD")).format(Date())
        
        val systemInstruction = buildString {
            append("You are Dharma AI, a Research-Based Hindu Dharma AI Assistant. Answer in Bengali. Current Date: $todayDate.\n")
            append("Never invent scripture references, shlokas, or mantras. Highlight different traditions if sources disagree.\n")
            append("If no reliable info is found, say 'এই তথ্যের নির্ভরযোগ্য শাস্ত্রীয় reference নিশ্চিত করা যায়নি।'\n")
            append("Structure Deep Research answers with headers: 🕉️ সংক্ষিপ্ত উত্তর, 📖 বিস্তারিত ব্যাখ্যা, 📚 শাস্ত্রীয়/ধর্মীয় Reference, 🔎 Research Summary, ⚠️ Verification Note.\n")
            
            if (localResults.isNotEmpty()) {
                append("\nLocal Knowledge Database:\n")
                localResults.take(3).forEach { k -> append("- [${k.category}] ${k.title}: ${k.content} (${k.scripture})\n") }
            }
            if (webResults.isNotEmpty()) {
                append("\nWeb Search Results:\n")
                webResults.forEach { w -> append("- ${w.domain}: ${w.title} (${w.snippet})\n") }
            }
        }
        
        val historyWithQuestion = chatHistory.toMutableList()
        historyWithQuestion.add(Content(role = "user", parts = listOf(Part(text = question))))
        return aiProvider.generateResponse(historyWithQuestion, systemInstruction)
    }
}
""")

# 4. Repository & ViewModel
write_file('app/src/main/java/com/example/ai/AiRepository.kt', """
package com.example.ai

import com.example.research.ResearchEngine
import com.example.research.WebResult
import com.example.research.YouTubeResult

data class ChatMessage(
    val isUser: Boolean, 
    val text: String, 
    val localSources: List<String> = emptyList(),
    val webSources: List<WebResult> = emptyList(),
    val youtubeSources: List<YouTubeResult> = emptyList()
)

class AiRepository(private val researchEngine: ResearchEngine) {
    suspend fun getAiResponse(
        question: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage {
        val apiHistory = history.map { Content(role = if (it.isUser) "user" else "model", parts = listOf(Part(text = it.text))) }
        val result = researchEngine.conductResearch(question, apiHistory, isDeepResearch, onProgress)
        return ChatMessage(
            isUser = false, 
            text = result.answer, 
            localSources = result.localSources.map { it.scripture }.filter { it.isNotBlank() }.distinct(),
            webSources = result.webSources,
            youtubeSources = result.youtubeSources
        )
    }
}
""")

write_file('app/src/main/java/com/example/ui/chat/ChatViewModel.kt', """
package com.example.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ai.AiRepository
import com.example.ai.ChatMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ChatUiState {
    object Idle : ChatUiState()
    data class Loading(val progressMessage: String) : ChatUiState()
    data class Error(val message: String) : ChatUiState()
}

class ChatViewModel(private val repository: AiRepository) : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _uiState = MutableStateFlow<ChatUiState>(ChatUiState.Idle)
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()
    
    private val _isDeepResearch = MutableStateFlow(true)
    val isDeepResearch: StateFlow<Boolean> = _isDeepResearch.asStateFlow()
    
    private var lastQuestion: String? = null

    fun toggleDeepResearch(enabled: Boolean) { _isDeepResearch.value = enabled }

    fun sendMessage(question: String) {
        if (question.isBlank()) return
        lastQuestion = question
        _messages.value = _messages.value + ChatMessage(isUser = true, text = question)
        _uiState.value = ChatUiState.Loading("Initializing...")
        
        viewModelScope.launch {
            try {
                val responseMsg = repository.getAiResponse(question, _messages.value.dropLast(1), _isDeepResearch.value) { progressMsg ->
                    _uiState.value = ChatUiState.Loading(progressMsg)
                }
                _messages.value = _messages.value + responseMsg
                _uiState.value = ChatUiState.Idle
            } catch (e: Exception) {
                _uiState.value = ChatUiState.Error(e.message ?: "Unknown error occurred.")
            }
        }
    }
    
    fun retry() {
        lastQuestion?.let {
            if (_messages.value.isNotEmpty() && _messages.value.last().isUser) {
                _messages.value = _messages.value.dropLast(1)
            }
            sendMessage(it)
        }
    }
}

class ChatViewModelFactory(private val repository: AiRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ChatViewModel(repository) as T
    }
}
""")
