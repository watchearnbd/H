with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    lines = f.readlines()

new_lines = []
for i, line in enumerate(lines):
    if 211 <= i + 1 <= 221:
        continue
    new_lines.append(line)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.writelines(new_lines)
