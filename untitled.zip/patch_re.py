import os

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    text = f.read()

target = """        try {
            finalAnswerText = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch, analysis.needsYouTube, analysis.category)
                } catch (e: Exception) {
            if (localResults.isNotEmpty()) {
                finalAnswerText = "⚠️ Network Error / Offline Mode: ইন্টারনেট সংযোগ না থাকায় AI বিশ্লেষণ সম্ভব হচ্ছে না। নিচে Local Knowledge Base থেকে প্রাপ্ত সরাসরি তথ্য দেওয়া হলো:\\n\\n" + localResults.joinToString("\\n\\n") { "📌 " + it.title + "\\n" + it.content }
            } else {
                throw e
            }
        }"""

replacement = """        try {
            finalAnswerText = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch, analysis.needsYouTube, analysis.category)
                } catch (e: Exception) {
            if (e.message == "AUTH_ERROR" || e.message?.contains("401") == true) {
                if (localResults.isNotEmpty()) {
                    finalAnswerText = "AI service এই মুহূর্তে সংযোগ করতে পারছে না। আপনার প্রশ্নটির উত্তর আমাদের verified Dharma Knowledge Base থেকে নিচে দেওয়া হলো:\\n\\n" + localResults.joinToString("\\n\\n") { "📌 " + it.title + "\\n" + it.content }
                } else {
                    throw Exception("AUTH_ERROR")
                }
            } else {
                if (localResults.isNotEmpty()) {
                    finalAnswerText = "⚠️ Network Error / Offline Mode: ইন্টারনেট সংযোগ না থাকায় AI বিশ্লেষণ সম্ভব হচ্ছে না। নিচে Local Knowledge Base থেকে প্রাপ্ত সরাসরি তথ্য দেওয়া হলো:\\n\\n" + localResults.joinToString("\\n\\n") { "📌 " + it.title + "\\n" + it.content }
                } else {
                    throw e
                }
            }
        }"""

text = text.replace(target, replacement)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(text)

