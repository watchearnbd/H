import os

with open('app/build.gradle.kts', 'r') as f:
    text = f.read()

if "testLogging {" not in text:
    text = text.replace(
        'testOptions {',
        'testOptions {\n        unitTests.all {\n            testLogging {\n                showStandardStreams = true\n            }\n        }'
    )

with open('app/build.gradle.kts', 'w') as f:
    f.write(text)

