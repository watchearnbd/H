import re

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

# Let's just use string concatenation with \n to be safe and clean.
good_block = 'append("Title: ${k.title}\\n" +\n                           "Category: ${k.category}\\n" +\n                           "Scripture: ${k.scripture}\\n" +\n                           "Reference: ${k.reference}\\n" +\n                           "Sanskrit Text: ${k.sanskritText}\\n" +\n                           "Transliteration: ${k.transliteration}\\n" +\n                           "Bangla Meaning: ${k.banglaMeaning}\\n" +\n                           "Content: ${k.content}\\n" +\n                           "Explanation: ${k.explanation}\\n" +\n                           "Source: ${k.source}\\n" +\n                           "Verified Status: ${k.verifiedStatus}\\n---\\n")'

content = re.sub(r'append\("""Title: \$\{k\.title\}\\n.*?---\\n"""\)', good_block, content, flags=re.DOTALL)
content = re.sub(r'append\("Title: \$\{k\.title\}\nCategory: \$\{k\.category\}\nScripture: \$\{k\.scripture\}\nReference: \$\{k\.reference\}\nSanskrit Text: \$\{k\.sanskritText\}\nTransliteration: \$\{k\.transliteration\}\nBangla Meaning: \$\{k\.banglaMeaning\}\nContent: \$\{k\.content\}\nExplanation: \$\{k\.explanation\}\nSource: \$\{k\.source\}\nVerified Status: \$\{k\.verifiedStatus\}\n---\n"\)', good_block, content, flags=re.DOTALL)


with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
