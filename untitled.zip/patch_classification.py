import os

with open('app/src/main/java/com/example/ai/AiProvider.kt', 'r') as f:
    text = f.read()

text = text.replace(
    'val youtubeSearchQuery: String? = null',
    'val youtubeSearchQuery: String? = null,\n    val category: String? = null'
)

text = text.replace(
    'Return ONLY a valid JSON object matching this structure:\n            {"needsWebSearch": boolean, "webSearchQuery": "english search string or null", "needsYouTube": boolean, "youtubeSearchQuery": "search string or null"}',
    'Classify the question into one of: GENERAL_KNOWLEDGE, DHARMA, SCRIPTURE, MANTRA, SHLOKA, PUJA, FESTIVAL, PHILOSOPHY, SCIENCE, HISTORY, EDUCATION, TECHNOLOGY, LANGUAGE, MATH, CASUAL_CONVERSATION, AMBIGUOUS, UNKNOWN.\n            Return ONLY a valid JSON object matching this structure:\n            {"needsWebSearch": boolean, "webSearchQuery": "english search string or null", "needsYouTube": boolean, "youtubeSearchQuery": "search string or null", "category": "CLASSIFICATION_HERE"}'
)

text = text.replace(
    'QueryAnalysis(false, null, false, null)',
    'QueryAnalysis(false, null, false, null, "UNKNOWN")'
)

with open('app/src/main/java/com/example/ai/AiProvider.kt', 'w') as f:
    f.write(text)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    r_text = f.read()

r_text = r_text.replace(
    'val analysis = aiProvider.analyzeQuery(question)',
    'val analysis = aiProvider.analyzeQuery(question)\n        onProgress("Category: ${analysis.category ?: "UNKNOWN"}")'
)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(r_text)

