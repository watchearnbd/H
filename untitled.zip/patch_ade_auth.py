import os

with open('app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt', 'r') as f:
    text = f.read()

# Make sure processPipeline catches AUTH_ERROR when calling researchEngine.conductResearch
target = """        // 5. Answer Generation
        var result = researchEngine.conductResearch(queryWithStrategy, apiHistory, effectiveDeepResearch, onProgress)
        
        // 6. Answer Self-Check"""

replacement = """        // 5. Answer Generation
        var result: ResearchResult
        try {
            result = researchEngine.conductResearch(queryWithStrategy, apiHistory, effectiveDeepResearch, onProgress)
        } catch (e: Exception) {
            if (e.message == "AUTH_ERROR") {
                val isGreeting = strategy == "GREETING_RESPONSE"
                val text = if (isGreeting) {
                    "নমস্কার 🙏 Dharma AI-তে আপনাকে স্বাগতম। আমি হিন্দু ধর্ম, দর্শন, শাস্ত্র নিয়ে সাহায্য করতে পারি। (Offline/Fallback Mode)"
                } else {
                    "AI service এই মুহূর্তে সংযোগ করতে পারছে না। আপনার প্রশ্নটি যদি আমাদের verified Dharma Knowledge Base-এ থাকে, সেখান থেকেই উত্তর দেওয়া হচ্ছে। এই মুহূর্তে এই প্রশ্নের কোনো verified উত্তর আমার কাছে নেই।"
                }
                result = ResearchResult(
                    answer = text,
                    verificationStatus = com.example.research.VerificationStatus.NONE
                )
            } else {
                throw e
            }
        }
        
        // 6. Answer Self-Check"""

text = text.replace(target, replacement)

with open('app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt', 'w') as f:
    f.write(text)

