import os

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    text = f.read()

text = text.replace(
    'generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch, analysis.needsYouTube)',
    'generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch, analysis.needsYouTube, analysis.category)'
)

text = text.replace(
    'needsExternalResearch: Boolean,\n        attemptedYouTubeSearch: Boolean\n    ): String {',
    'needsExternalResearch: Boolean,\n        attemptedYouTubeSearch: Boolean,\n        queryCategory: String?\n    ): String {'
)

text = text.replace(
    'append("Query Classification: ${analysis.category ?: "UNKNOWN"}\\n")',
    'append("Query Classification: ${queryCategory ?: "UNKNOWN"}\\n")'
)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(text)

