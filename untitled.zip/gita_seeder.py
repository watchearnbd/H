import re

with open('app/src/main/java/com/example/data/KnowledgeSeeder.kt', 'r') as f:
    content = f.read()

# Extract existing entities
entities_str = content[content.find("listOf(")+7 : content.rfind(")")]

gita_chapters = """
        KnowledgeEntity(
            title = "অর্জুন বিষাদ যোগ (Arjuna Visada Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 1",
            scripture = "ভগবদ্গীতা",
            chapter = "1",
            reference = "অধ্যায় ১",
            content = "কুরুক্ষেত্র যুদ্ধে আত্মীয়-স্বজনদের দেখে অর্জুনের মনে গভীর বিষাদ ও মোহ তৈরি হয়। তিনি যুদ্ধ করতে অস্বীকার করেন।",
            explanation = "এটি গীতার প্রথম অধ্যায় যেখানে মানুষের মনের দ্বন্দ্ব এবং কর্তব্যের প্রতি অনীহা ফুটে উঠেছে।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১, অর্জুন, বিষাদ, ভগবদগীতা, Bhagavad Gita Chapter 1, Arjuna Visada Yoga"
        ),
        KnowledgeEntity(
            title = "সাংখ্য যোগ (Sankhya Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 2",
            scripture = "ভগবদ্গীতা",
            chapter = "2",
            reference = "অধ্যায় ২",
            content = "শ্রীকৃষ্ণ অর্জুনকে আত্মার অমরত্ব এবং নিষ্কাম কর্মের ধারণা বোঝান। এখানেই স্থিতপ্রজ্ঞ (Sthitaprajna) বা স্থিতধী ব্যক্তির লক্ষণ বর্ণনা করা হয়েছে।",
            explanation = "এটি গীতার অন্যতম গুরুত্বপূর্ণ অধ্যায় যেখানে সমগ্র গীতার সারসংক্ষেপ রয়েছে। কর্মযোগ এবং আত্মজ্ঞানের প্রাথমিক ভিত্তি এখানে স্থাপিত।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ২, সাংখ্য যোগ, আত্মা, কর্মযোগ, স্থিতপ্রজ্ঞ, Bhagavad Gita Chapter 2, Sankhya Yoga, Atman, Karma Yoga, Sthitaprajna"
        ),
        KnowledgeEntity(
            title = "কর্ম যোগ (Karma Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 3",
            scripture = "ভগবদ্গীতা",
            chapter = "3",
            reference = "অধ্যায় ৩",
            content = "ফলাকাঙ্ক্ষা ত্যাগ করে নিজের কর্তব্য পালন করার শিক্ষাই হলো কর্মযোগ। কাজ না করে কেউ থাকতে পারে না, তাই নিষ্কামভাবে কাজ করা উচিত।",
            explanation = "ঈশ্বরকে সন্তুষ্ট করার উদ্দেশ্যে এবং জগতের কল্যাণে নিঃস্বার্থভাবে কাজ করার গুরুত্ব এখানে আলোচিত হয়েছে।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ৩, কর্মযোগ, নিষ্কাম কর্ম, Bhagavad Gita Chapter 3, Karma Yoga, Duty, Karma"
        ),
        KnowledgeEntity(
            title = "জ্ঞান-কর্ম-সন্ন্যাস যোগ (Jnana-Karma-Sanyasa Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 4",
            scripture = "ভগবদ্গীতা",
            chapter = "4",
            reference = "অধ্যায় ৪",
            content = "এই অধ্যায়ে শ্রীকৃষ্ণ তাঁর অবতার তত্ত্ব (Avatar) এবং দিব্য কর্মের কথা প্রকাশ করেছেন। জ্ঞানরূপ অগ্নির মাধ্যমে কীভাবে সমস্ত কর্মফল ভস্মীভূত হয় তা বোঝানো হয়েছে।",
            explanation = "ভগবান যুগে যুগে ধর্ম রক্ষার্থে অবতীর্ণ হন। জ্ঞানই হলো শ্রেষ্ঠ পবিত্রতাকারী বস্তু।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ৪, জ্ঞান যোগ, অবতার, Bhagavad Gita Chapter 4, Jnana Yoga, Avatar"
        ),
        KnowledgeEntity(
            title = "কর্ম-সন্ন্যাস যোগ (Karma-Sanyasa Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 5",
            scripture = "ভগবদ্গীতা",
            chapter = "5",
            reference = "অধ্যায় ৫",
            content = "কর্মসন্ন্যাস (কর্মত্যাগ) এবং কর্মযোগ (নিষ্কাম কর্ম)—এই দুটির মধ্যে কর্মযোগই শ্রেষ্ঠ। যোগী ব্যক্তি পদ্মপাতায় জলের মতো নির্লিপ্ত থাকেন।",
            explanation = "সন্ন্যাস মানে কাজ ছেড়ে দেওয়া নয়, বরং কাজের ফলের প্রতি আসক্তি ছেড়ে দেওয়া।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ৫, সন্ন্যাস, কর্মযোগ, Bhagavad Gita Chapter 5, Sanyasa"
        ),
        KnowledgeEntity(
            title = "ধ্যান যোগ / আত্মসংযম যোগ (Dhyana Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 6",
            scripture = "ভগবদ্গীতা",
            chapter = "6",
            reference = "অধ্যায় ৬",
            content = "মন নিয়ন্ত্রণের মাধ্যমে ধ্যানে মগ্ন হওয়ার উপায় এবং যোগীর জীবনযাত্রা বর্ণিত হয়েছে। মন চঞ্চল হলেও অভ্যাসের দ্বারা তাকে বশ করা সম্ভব।",
            explanation = "যে ব্যক্তি মন জয় করেছেন, তাঁর মন তাঁর পরম বন্ধু; আর যিনি তা পারেননি, মন তাঁর শত্রু।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ৬, ধ্যান যোগ, মন, যোগ, Bhagavad Gita Chapter 6, Dhyana Yoga, Meditation, Mind"
        ),
        KnowledgeEntity(
            title = "জ্ঞান-বিজ্ঞান যোগ (Jnana-Vijnana Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 7",
            scripture = "ভগবদ্গীতা",
            chapter = "7",
            reference = "অধ্যায় ৭",
            content = "পরমার্থিক জ্ঞান এবং বিজ্ঞান (অনুভূতিমূলক জ্ঞান)। শ্রীকৃষ্ণ নিজেকে সমগ্র জগতের উৎপত্তি ও প্রলয়ের কারণ হিসেবে ঘোষণা করেছেন।",
            explanation = "চার প্রকার ভক্ত ভগবানের ভজনা করেন: আর্ত, জিজ্ঞাসু, অর্থার্থী এবং জ্ঞানী। এদের মধ্যে জ্ঞানী ভক্তই শ্রেষ্ঠ।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ৭, জ্ঞান-বিজ্ঞান, ભক্তি, Bhagavad Gita Chapter 7, Jnana Vijnana"
        ),
        KnowledgeEntity(
            title = "অক্ষরব্রহ্ম যোগ (Aksara-Brahma Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 8",
            scripture = "ভগবদ্গীতা",
            chapter = "8",
            reference = "অধ্যায় ৮",
            content = "ব্রহ্ম (Brahman), অধ্যাত্ম, কর্ম, এবং মৃত্যুর সময় ভগবানের স্মরণের গুরুত্ব নিয়ে আলোচনা।",
            explanation = "মৃত্যুকালে মানুষ যা স্মরণ করে, সে সেই ভাবই প্রাপ্ত হয়। তাই সর্বদা ঈশ্বর স্মরণ করে কর্ম করা উচিত।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ৮, ব্রহ্ম, অক্ষরব্রহ্ম, মৃত্যু, Bhagavad Gita Chapter 8, Brahman, Death"
        ),
        KnowledgeEntity(
            title = "রাজবিদ্যা-রাজগুহ্য যোগ (Rajavidya-Rajaguhya Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 9",
            scripture = "ভগবদ্গীতা",
            chapter = "9",
            reference = "অধ্যায় ৯",
            content = "এটি সর্বশ্রেষ্ঠ গুপ্ত বিদ্যা। ভগবান শ্রীকৃষ্ণ জানিয়েছেন যে ভক্তিভরে যে কেউ তাঁকে পত্র, পুষ্প, ফল বা জল অর্পণ করলে তিনি তা প্রীতিপূর্বক গ্রহণ করেন।",
            explanation = "ঈশ্বরের প্রতি অনন্য ভক্তি এবং তাঁর শরণাগত হওয়ার শ্রেষ্ঠত্ব বর্ণিত হয়েছে।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ৯, রাজবিদ্যা, ভক্তি, ভক্তিযোগ, Bhagavad Gita Chapter 9, Rajavidya, Bhakti Yoga"
        ),
        KnowledgeEntity(
            title = "বিভূতি যোগ (Vibhuti Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 10",
            scripture = "ভগবদ্গীতা",
            chapter = "10",
            reference = "অধ্যায় ১০",
            content = "ভগবানের অসীম ঐশ্বর্য ও বিভূতির বর্ণনা। বিশ্বে যেখানে যা কিছু ঐশ্বর্যশালী, শ্রীমৎ বা তেজস্বী, তা তাঁরই তেজের অংশ থেকে উদ্ভূত।",
            explanation = "সবকিছুর মধ্যেই ঈশ্বরের উপস্থিতি উপলব্ধি করার উপায় এখানে বলা হয়েছে।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১০, বিভূতি, ঐশ্বর্য, Bhagavad Gita Chapter 10, Vibhuti"
        ),
        KnowledgeEntity(
            title = "বিশ্বরূপ দর্শন যোগ (Visvarupa-Darsana Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 11",
            scripture = "ভগবদ্গীতা",
            chapter = "11",
            reference = "অধ্যায় ১১",
            content = "অর্জুন শ্রীকৃষ্ণের দিব্য বিশ্বরূপ দর্শন করেন। এটি এক অত্যন্ত ঐশ্বরিক, বিস্ময়কর এবং ভীতিকর রূপ।",
            explanation = "ভগবান দেখান যে সমগ্র সৃষ্টি তাঁর মধ্যেই নিহিত এবং কালের নিয়মে সবই তাঁর মধ্যে লীন হয়ে যায়।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১১, বিশ্বরূপ, দর্শন, Bhagavad Gita Chapter 11, Visvarupa"
        ),
        KnowledgeEntity(
            title = "ভক্তি যোগ (Bhakti Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 12",
            scripture = "ভগবদ্গীতা",
            chapter = "12",
            reference = "অধ্যায় ১২",
            content = "নিরাকার ব্রহ্মের উপাসনা এবং সাকার ভগবানের ভক্তির মধ্যে সাকার উপাসনা সাধারণ মানুষের জন্য বেশি সহজ।",
            explanation = "একজন আদর্শ ভক্তের গুণাবলী (যেমন অদ্বেষ্টা, করুণাপূর্ণ, ক্ষমাবান) এখানে বিস্তারিতভাবে বলা হয়েছে।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১২, ভক্তি যোগ, ভক্তি, Bhagavad Gita Chapter 12, Bhakti Yoga, Devotion"
        ),
        KnowledgeEntity(
            title = "ক্ষেত্র-ক্ষেত্রজ্ঞ বিভাগ যোগ (Ksetra-Ksetrajna Vibhaga Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 13",
            scripture = "ভগবদ্গীতা",
            chapter = "13",
            reference = "অধ্যায় ১৩",
            content = "ক্ষেত্র (দেহ বা প্রকৃতি) এবং ক্ষেত্রজ্ঞ (আত্মা বা পরমাত্মা) এর মধ্যে পার্থক্য আলোচনা করা হয়েছে।",
            explanation = "প্রকৃতি এবং পুরুষের ভেদজ্ঞান লাভ করাই প্রকৃত জ্ঞান।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১৩, ক্ষেত্র, ক্ষেত্রজ্ঞ, প্রকৃতি, পুরুষ, Bhagavad Gita Chapter 13, Prakriti, Purusha"
        ),
        KnowledgeEntity(
            title = "গুণত্রয় বিভাগ যোগ (Gunatraya-Vibhaga Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 14",
            scripture = "ভগবদ্গীতা",
            chapter = "14",
            reference = "অধ্যায় ১৪",
            content = "প্রকৃতির তিনটি গুণ—সত্ত্ব, রজঃ এবং তমঃ সম্পর্কে বিস্তারিত বিশ্লেষণ। এই গুণগুলো কীভাবে জীবকে আবদ্ধ করে তা বোঝানো হয়েছে।",
            explanation = "মোক্ষ (Moksha) লাভের জন্য এই তিনটি গুণের অতীত (গুণাতীত) হতে হবে।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১৪, গুণত্রয়, সত্ত্ব, রজঃ, তমঃ, Gunatraya, Sattva, Rajas, Tamas, Bhagavad Gita Chapter 14"
        ),
        KnowledgeEntity(
            title = "পুরুষোত্তম যোগ (Purusottama Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 15",
            scripture = "ভগবদ্গীতা",
            chapter = "15",
            reference = "অধ্যায় ১৫",
            content = "সংসারকে একটি উল্টানো অশ্বত্থ গাছের সাথে তুলনা করা হয়েছে। ভগবান হলেন ক্ষর (বিনাশশীল বস্তু) এবং অক্ষর (অবিনাশী আত্মা)-এর অতীত 'পুরুষোত্তম'।",
            explanation = "সর্বশ্রেষ্ঠ তত্ত্ব বা ঈশ্বরকে জানার উপায় এখানে বর্ণিত।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১৫, পুরুষোত্তম, অশ্বত্থ, Bhagavad Gita Chapter 15, Purushottama"
        ),
        KnowledgeEntity(
            title = "দৈবাসুর সম্পদ বিভাগ যোগ (Daivasura-Sampad-Vibhaga Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 16",
            scripture = "ভগবদ্গীতা",
            chapter = "16",
            reference = "অধ্যায় ১৬",
            content = "দৈবী সম্পদ (শুভ গুণাবলী) এবং আসুরিক সম্পদ (অশুভ গুণাবলী)-এর মধ্যে পার্থক্য।",
            explanation = "কাম, ক্রোধ এবং লোভ—এই তিনটিকে নরকের দ্বার বলা হয়েছে এবং এগুলো ত্যাগের নির্দেশ দেওয়া হয়েছে।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১৬, দৈবী, আসুরিক, কাম, ক্রোধ, লোভ, Bhagavad Gita Chapter 16"
        ),
        KnowledgeEntity(
            title = "শ্রদ্ধাত্রয় বিভাগ যোগ (Sraddhatraya-Vibhaga Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 17",
            scripture = "ভগবদ্গীতা",
            chapter = "17",
            reference = "অধ্যায় ১৭",
            content = "মানুষের শ্রদ্ধা, আহার, যজ্ঞ, তপস্যা এবং দান কীভাবে সত্ত্ব, রজঃ ও তমঃ গুণের প্রভাবে তিন প্রকার হয়, তার বর্ণনা।",
            explanation = "'ওঁ তৎ সৎ' মন্ত্রের তাৎপর্য ব্যাখ্যা করা হয়েছে।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১৭, শ্রদ্ধা, আহার, যজ্ঞ, দান, Bhagavad Gita Chapter 17"
        ),
        KnowledgeEntity(
            title = "মোক্ষ-সন্ন্যাস যোগ (Moksha-Sanyasa Yoga)",
            category = "Bhagavad Gita",
            subcategory = "Chapter 18",
            scripture = "ভগবদ্গীতা",
            chapter = "18",
            reference = "অধ্যায় ১৮",
            content = "গীতার শেষ অধ্যায় এবং সমগ্র গীতার সারসংক্ষেপ। সন্ন্যাস ও ত্যাগের পার্থক্য এবং পরম মোক্ষ (Moksha) বা মুক্তির উপায় বলা হয়েছে।",
            explanation = "'সর্বধর্মান্ পরিত্যজ্য মামেকং শরণং ব্রজ'—সব ধর্ম বা আশ্রয় ত্যাগ করে কেবল ঈশ্বরের শরণাগত হওয়াই পরম মুক্তির পথ।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতা, অধ্যায় ১৮, মোক্ষ, সন্ন্যাস, শরণাগতি, Bhagavad Gita Chapter 18, Moksha, Sanyasa, Surrender"
        )
"""

# Let's adjust existing entities related to Gita to have Category="Bhagavad Gita" and matching fields
# For Avatar Tattva and Karma Yoga, they are already in the list.
# We will just write the file combining them safely.

new_seeder_content = f"""package com.example.data

object KnowledgeSeeder {{
    val initialData = listOf(
{entities_str},
{gita_chapters}
    )
}}
"""

# Fix existing ones in entities_str to align with Gita category if they are from Gita
entities_str = entities_str.replace('category = "Hindu Philosophy",\n            scripture = "ভগবদ্গীতা",', 'category = "Bhagavad Gita",\n            scripture = "ভগবদ্গীতা",')

# Re-build again
new_seeder_content = f"""package com.example.data

object KnowledgeSeeder {{
    val initialData = listOf(
{entities_str},
{gita_chapters}
    )
}}
"""

with open('app/src/main/java/com/example/data/KnowledgeSeeder.kt', 'w') as f:
    f.write(new_seeder_content)

print("Updated KnowledgeSeeder.kt")
