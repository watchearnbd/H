import re

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

bad_string = 'append("Title: ${k.title}Category: ${k.category}Scripture: ${k.scripture}Reference: ${k.reference}Sanskrit Text: ${k.sanskritText}Transliteration: ${k.transliteration}Bangla Meaning: ${k.banglaMeaning}Content: ${k.content}Explanation: ${k.explanation}Source: ${k.source}Verified Status: ${k.verifiedStatus}---")'

good_string = 'append("Title: ${k.title}\\nCategory: ${k.category}\\nScripture: ${k.scripture}\\nReference: ${k.reference}\\nSanskrit Text: ${k.sanskritText}\\nTransliteration: ${k.transliteration}\\nBangla Meaning: ${k.banglaMeaning}\\nContent: ${k.content}\\nExplanation: ${k.explanation}\\nSource: ${k.source}\\nVerified Status: ${k.verifiedStatus}\\n---\\n")'

content = content.replace(bad_string, good_string)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
