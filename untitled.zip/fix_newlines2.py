import re

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

# Replace the broken block
old_block = r'append\("Title: \$\{k\.title\}\nCategory: \$\{k\.category\}\nScripture: \$\{k\.scripture\}\nReference: \$\{k\.reference\}\nSanskrit Text: \$\{k\.sanskritText\}\nTransliteration: \$\{k\.transliteration\}\nBangla Meaning: \$\{k\.banglaMeaning\}\nContent: \$\{k\.content\}\nExplanation: \$\{k\.explanation\}\nSource: \$\{k\.source\}\nVerified Status: \$\{k\.verifiedStatus\}\n---\n"\)'
new_block = 'append("""Title: ${k.title}\\nCategory: ${k.category}\\nScripture: ${k.scripture}\\nReference: ${k.reference}\\nSanskrit Text: ${k.sanskritText}\\nTransliteration: ${k.transliteration}\\nBangla Meaning: ${k.banglaMeaning}\\nContent: ${k.content}\\nExplanation: ${k.explanation}\\nSource: ${k.source}\\nVerified Status: ${k.verifiedStatus}\\n---\\n""")'

content = re.sub(old_block, new_block, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
