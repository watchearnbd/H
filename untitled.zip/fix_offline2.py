import re
with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

replacement = """finalAnswerText = "⚠️ Network Error / Offline Mode: ইন্টারনেট সংযোগ না থাকায় AI বিশ্লেষণ সম্ভব হচ্ছে না। নিচে Local Knowledge Base থেকে প্রাপ্ত সরাসরি তথ্য দেওয়া হলো:\\n\\n" + localResults.joinToString("\\n\\n") { "📌 " + it.title + "\\n" + it.content }"""

content = re.sub(r'finalAnswerText = "Network Error \(Offline Mode\)[^"]*" \+ localResults\.joinToString\("\\n\\n"\) \{ "📌 " \+ it\.title \+ "\\\\n" \+ it\.content \}', replacement, content)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
