with open('app/src/main/java/com/example/data/KnowledgeSeeder.kt', 'r') as f:
    content = f.read()

content = content.replace('sanskritText = "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन।\\nमा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥"', 'sanskritText = "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥"')
content = content.replace('transliteration = "karmaṇyevādhikāraste mā phaleṣu kadācana\\nmā karmaphalaheturbhūrmā te saṅgo\'stvakarmani"', 'transliteration = "karmaṇyevādhikāraste mā phaleṣu kadācana mā karmaphalaheturbhūrmā te saṅgo\'stvakarmani"')

# Ensure no actual newline is inside double quotes
with open('app/src/main/java/com/example/data/KnowledgeSeeder.kt', 'w') as f:
    f.write(content)
