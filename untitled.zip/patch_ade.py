import os

with open('app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt', 'r') as f:
    text = f.read()

# Update processPipeline to skip research for simple greetings/clarifications if possible, or forcefully disable external research
text = text.replace(
    'var result = researchEngine.conductResearch(queryWithStrategy, apiHistory, isDeepResearch, onProgress)',
    '''
        val forceSkipResearch = strategy == "GREETING_RESPONSE" || strategy == "CLARIFICATION"
        val effectiveDeepResearch = if (forceSkipResearch) false else isDeepResearch
        var result = researchEngine.conductResearch(queryWithStrategy, apiHistory, effectiveDeepResearch, onProgress)
    '''
)

with open('app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt', 'w') as f:
    f.write(text)

