import os

with open('app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt', 'r') as f:
    text = f.read()

target = """        // 8. Follow-Up Decision
        var followUps = result.suggestedQuestions
        if (selfCheckResult.recommendedFollowUps.isNotEmpty()) {
            followUps = selfCheckResult.recommendedFollowUps
        }
        val maxFollowUps = when (strategy) {
            "GREETING_RESPONSE", "CLARIFICATION", "UNKNOWN_KNOWLEDGE", "GIBBERISH" -> 0
            "SHORT", "DIRECT_ANSWER" -> 2
            "RESEARCH", "DETAILED_EXPLANATION" -> 4
            else -> 3
        }
        followUps = followUps.take(maxFollowUps)
        
        return@withContext ChatMessage(
            isUser = false, 
            text = finalAnswer, 
            localSources = result.localSources.map { "\${it.scripture} (\${it.reference})" }.filter { it.isNotBlank() }.distinct(),
            webSources = result.webSources,
            youtubeSources = result.youtubeSources,
            verificationStatus = result.verificationStatus,
            sourceMetadata = result.sourceMetadata,
            suggestedQuestions = followUps
        )
    }"""

replacement = """        // 8. Follow-Up Decision
        var followUps = result.suggestedQuestions
        if (selfCheckResult.recommendedFollowUps.isNotEmpty()) {
            followUps = selfCheckResult.recommendedFollowUps
        }
        val maxFollowUps = when (strategy) {
            "GREETING_RESPONSE", "CLARIFICATION", "UNKNOWN_KNOWLEDGE", "GIBBERISH" -> 0
            "SHORT", "DIRECT_ANSWER" -> 2
            "RESEARCH", "DETAILED_EXPLANATION" -> 4
            else -> 3
        }
        followUps = followUps.take(maxFollowUps)
        
        return@withContext ChatMessage(
            isUser = false, 
            text = finalAnswer, 
            localSources = result.localSources.map { "\${it.scripture} (\${it.reference})" }.filter { it.isNotBlank() }.distinct(),
            webSources = result.webSources,
            youtubeSources = result.youtubeSources,
            verificationStatus = result.verificationStatus,
            sourceMetadata = result.sourceMetadata,
            suggestedQuestions = followUps
        )
    }"""

# Actually, we can just wrap the whole generation block in a try-catch for AUTH_ERROR, or just ensure `ChatViewModel` doesn't crash but shows the fallback.
# Wait, `ChatViewModel` catches ALL exceptions and shows an Error UI.
# Let's fix ChatViewModel instead, to catch AUTH_ERROR and output a regular ChatMessage if it's an Auth Error, rather than an Error state. Or just let `AdvancedDecisionEngine` handle it completely.

