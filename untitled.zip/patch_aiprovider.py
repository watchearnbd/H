import os

with open('app/src/main/java/com/example/ai/AiProvider.kt', 'r') as f:
    text = f.read()

# Replace exception handling in generateResponse
target = """        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            if (response.error != null) {
                throw Exception("API Error: ${response.error}")
            }
            
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: throw Exception("Empty response from AI")
        } catch (e: Exception) {}
        
        return@withContext QueryAnalysis(false, null, false, null, "UNKNOWN")"""

target_gen = """        val response = RetrofitClient.service.generateContent(apiKey, request)
        if (response.error != null) {
            throw Exception("API Error: ${response.error}")
        }
        
        response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            ?: throw Exception("Empty response from AI")"""

replacement_gen = """        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            if (response.error != null) {
                throw Exception("API Error: ${response.error}")
            }
            
            return@withContext response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: throw Exception("Empty response from AI")
        } catch (e: retrofit2.HttpException) {
            if (e.code() == 401 || e.code() == 403 || e.code() == 400) {
                throw Exception("AUTH_ERROR")
            }
            throw e
        } catch (e: Exception) {
            val msg = e.message ?: ""
            if (msg.contains("401") || msg.contains("403") || msg.contains("API key")) {
                throw Exception("AUTH_ERROR")
            }
            throw e
        }"""

text = text.replace(target_gen, replacement_gen)

with open('app/src/main/java/com/example/ai/AiProvider.kt', 'w') as f:
    f.write(text)

