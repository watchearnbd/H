with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

# Add Puja formatting rules
new_rules = """            append("6a. For Bhagavad Gita related questions, use this specific format when appropriate:\\n📖 Bhagavad Gita\\n📍 Chapter / Verse\\n🕉️ শ্লোক\\n🔤 Transliteration\\n📝 বাংলা অর্থ\\n💡 সহজ ব্যাখ্যা\\n🔎 Verification\\n📚 Source\\nDo NOT invent unverified fields.\\n")
            append("7. Transliteration এবং pronunciation একই জিনিস ধরে নেবে না। যদি নির্ভরযোগ্য pronunciation data না থাকে: 'উচ্চারণের তথ্য যাচাই করা হয়নি।' দেখাতে পারবে। নিজে থেকে Sanskrit pronunciation তৈরি করবে না।\\n")
            append("8. YouTube videos are educational resources; their scriptural authenticity must be verified separately. If referencing a video, mention: 'এই ভিডিওটি একটি reference resource; এর বক্তব্যের শাস্ত্রীয় সত্যতা আলাদাভাবে যাচাই করা হয়েছে/হয়নি।'\\n")
            append("9. If a Puja or Festival is asked about, format the answer with:\\n🪔 উৎসব / পূজা\\n📖 ধর্মীয় ও ঐতিহ্যগত তাৎপর্য\\n🕉️ প্রচলিত রীতি\\n🌏 Regional / Tradition Variation\\n📍 Reference\\n🔎 Verification\\n📚 Sources\\n")
            append("10. Regional/Tradition Awareness for Festivals/Pujas: NEVER claim a ritual is universal if not proven. Use 'অঞ্চল ও tradition অনুযায়ী রীতিতে পার্থক্য থাকতে পারে।' where applicable. Do not invent rituals, materials, or fake history.\\n")"""

content = content.replace(
    'append("6a. For Bhagavad Gita related questions, use this specific format when appropriate:\\n📖 Bhagavad Gita\\n📍 Chapter / Verse\\n🕉️ শ্লোক\\n🔤 Transliteration\\n📝 বাংলা অর্থ\\n💡 সহজ ব্যাখ্যা\\n🔎 Verification\\n📚 Source\\nDo NOT invent unverified fields.\\n")\n            append("7. Transliteration এবং pronunciation একই জিনিস ধরে নেবে না। যদি নির্ভরযোগ্য pronunciation data না থাকে: \'উচ্চারণের তথ্য যাচাই করা হয়নি।\' দেখাতে পারবে। নিজে থেকে Sanskrit pronunciation তৈরি করবে না।\\n")\n            append("8. YouTube videos are educational resources; their scriptural authenticity must be verified separately. If referencing a video, mention: \'এই ভিডিওটি একটি reference resource; এর বক্তব্যের শাস্ত্রীয় সত্যতা আলাদাভাবে যাচাই করা হয়েছে/হয়নি।\'\\n")',
    new_rules
)

# Add new fields to printing local results
old_printing = """                           "Sanskrit Text: ${k.sanskritText}\\n" +
                           "Transliteration: ${k.transliteration}\\n" +
                           "Bangla Meaning: ${k.banglaMeaning}\\n" +
                           "Content: ${k.content}\\n" +
                           "Explanation: ${k.explanation}\\n" +
                           "Source: ${k.source}\\n" +
                           "Verified Status: ${k.verifiedStatus}\\n---\\n")"""

new_printing = """                           "Sanskrit Text: ${k.sanskritText}\\n" +
                           "Transliteration: ${k.transliteration}\\n" +
                           "Bangla Meaning: ${k.banglaMeaning}\\n" +
                           "Content: ${k.content}\\n" +
                           "Explanation: ${k.explanation}\\n" +
                           "Deity: ${k.deity}\\n" +
                           "Traditional Practice: ${k.traditionalPractice}\\n" +
                           "Regional Variation: ${k.regionalVariation}\\n" +
                           "Significance: ${k.significance}\\n" +
                           "Materials: ${k.materials}\\n" +
                           "Mantra References: ${k.mantraReferences}\\n" +
                           "Historical Context: ${k.historicalContext}\\n" +
                           "Source: ${k.source}\\n" +
                           "Verified Status: ${k.verifiedStatus}\\n---\\n")"""

content = content.replace(old_printing, new_printing)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
