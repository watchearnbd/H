import os

with open('app/src/main/java/com/example/ui/chat/ChatViewModel.kt', 'r') as f:
    text = f.read()

text = text.replace(
    'import com.example.ai.ConversationBrain',
    'import com.example.ai.AdvancedDecisionEngine'
)

text = text.replace(
    'class ChatViewModel(\n    private val conversationBrain: ConversationBrain,',
    'class ChatViewModel(\n    private val decisionEngine: AdvancedDecisionEngine,'
)

text = text.replace(
    'val responseMsg = conversationBrain.processConversation(question, _messages.value.dropLast(1), _isDeepResearch.value) { progressMsg ->',
    'val responseMsg = decisionEngine.processPipeline(question, _messages.value.dropLast(1), _isDeepResearch.value) { progressMsg ->'
)

text = text.replace(
    'class ChatViewModelFactory(\n    private val conversationBrain: ConversationBrain,',
    'class ChatViewModelFactory(\n    private val decisionEngine: AdvancedDecisionEngine,'
)

text = text.replace(
    'return ChatViewModel(conversationBrain, repository, chatSessionDao) as T',
    'return ChatViewModel(decisionEngine, repository, chatSessionDao) as T'
)

with open('app/src/main/java/com/example/ui/chat/ChatViewModel.kt', 'w') as f:
    f.write(text)

