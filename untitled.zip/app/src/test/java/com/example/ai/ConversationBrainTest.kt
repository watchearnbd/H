package com.example.ai

import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.Ignore

class ConversationBrainTest {

    @Test
    fun testConversationBrain() = runBlocking {
        // Just mocking the repo to avoid initializing the full dependency graph
        val mockRepo = AiRepository(
            com.example.research.ResearchEngine(
                com.example.research.LocalKnowledgeProviderImpl(),
                com.example.research.WebSearchProviderImpl(),
                com.example.research.YouTubeSearchProviderImpl(),
                com.example.research.ScriptureVerificationProviderImpl(),
                GeminiAiProvider()
            )
        )
        val brain = ConversationBrain(mockRepo)
        
        val queries = listOf(
            "হাই",
            "কর্মযোগ কী?",
            "এটা কী?",
            "এর মানে কী?",
            "আরও সহজ করে বলো",
            "একটা উদাহরণ দাও",
            "শক্তি কী?",
            "আমি এটা বোঝাইনি",
            "আমি বুঝতে পারছি না",
            "গায়ত্রী মন্ত্র শিখতে চাই"
        )
        
        val history = mutableListOf<ChatMessage>()
        
        for (q in queries) {
            println("\n----- QUERY: $q -----")
            val analysis = brain.analyzeConversationState(q, history)
            println("Intents: ${analysis.userIntents}")
            println("Resolved Query: ${analysis.resolvedQuery}")
            println("Clarification Needed: ${analysis.clarificationNeeded}")
            println("Response Depth: ${analysis.responseDepth}")
            
            // Simulate adding to history
            history.add(ChatMessage(isUser = true, text = q))
            // Assume AI answered
            history.add(ChatMessage(isUser = false, text = "This is a simulated answer for $q."))
        }
    }
}
