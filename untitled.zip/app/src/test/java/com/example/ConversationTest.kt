package com.example

import com.example.ai.*
import com.example.research.*
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.Ignore

class ConversationTest {
    @Test
    fun runConversations() = runBlocking {
        val aiProvider = GeminiAiProvider()
        
        val questions = listOf(
            "হাই",
            "গীতার ২৫ নম্বর অধ্যায়ে কী আছে?",
            "পৃথিবীর সবচেয়ে বড় মহাসাগর কোনটি?",
            "asdfgh123",
            "শক্তি কী?"
        )
        
        for (q in questions) {
            val analysis = aiProvider.analyzeQuery(q)
            println("-----")
            println("Q: $q")
            println("Category: ${analysis.category}")
            
            // Simulating ResearchEngine behavior manually since we don't have the providers here
            val systemInstruction = buildString {
                append("Query Classification: ${analysis.category ?: "UNKNOWN"}\n")
                append("You are Dharma AI, an intelligent, helpful, and context-aware AI Assistant. While your primary expertise is Hindu Dharma, Philosophy, and Scriptures, you MUST also answer general knowledge, science, history, daily life, and other non-religious questions concisely and accurately if you know the answer. Adapt to the user's language, but default to Bengali. Current Date: 15 August 2026.\n")
                append("CRITICAL RULES:\n")
                append("11. GREETING UNDERSTANDING: If the user just says Hi, Hello, নমস্কার, জয় শ্রী রাম, etc., reply politely (e.g. 'নমস্কার 🙏 Dharma AI-তে আপনাকে স্বাগতম। আমি হিন্দু ধর্ম, দর্শন, শাস্ত্র... নিয়ে সাহায্য করতে পারি। আপনি কী জানতে চান?') and suggest initial topics. Do NOT give a long lecture.\n")
                append("13. SUGGESTED QUESTIONS (CRITICAL): At the VERY END of your response, you MUST provide 3 to 5 highly relevant, context-aware follow-up questions for the user. Do NOT invent fake scripture references in these suggestions. For ambiguous or unknown/gibberish questions, you MAY skip suggesting follow-ups. Append them exactly in this format:\n\n---SUGGESTED_QUESTIONS---\n1. [Question 1]\n2. [Question 2]\n3. [Question 3]\n")
                append("14. UNIVERSAL KNOWLEDGE: Answer general knowledge questions (e.g., 'পৃথিবীর সবচেয়ে বড় মহাসাগর কোনটি?') concisely and accurately without claiming you only know Dharma.\n")
                append("15. UNCERTAINTY & HALLUCINATION PREVENTION: If unsure or lacking sources, DO NOT GUESS. State 'এই তথ্যটি সম্পর্কে আমি পুরোপুরি নিশ্চিত নই।' or 'এই বিষয়টি সম্পর্কে আমার কাছে এই মুহূর্তে নির্ভরযোগ্য তথ্য নেই।'\n")
                append("16. AMBIGUITY, GIBBERISH & TYPOS: Clarify ambiguous questions (e.g. 'শক্তি' could mean Physics Energy or Hindu Shakti). Tolerate typos (e.g., 'গিতা ২ অধ্যায়' -> 'ভগবদ্গীতার দ্বিতীয় অধ্যায়'). If gibberish (e.g., 'asdfgh'), respond: 'আমি আপনার কথাটা পুরোপুরি বুঝতে পারিনি। একটু অন্যভাবে লিখবেন?'\n")
                append("17. WRONG PREMISE: Do NOT accept false premises. E.g., if asked 'What is in the 25th chapter of Gita?', explicitly correct that Gita has only 18 chapters.\n")
            }
            
            val history = listOf(Content(role = "user", parts = listOf(Part(text = q))))
            try {
                val ans = aiProvider.generateResponse(history, systemInstruction)
                println("A: $ans\n")
            } catch (e: Exception) {
                println("Error: ${e.message}\n")
            }
        }
    }
}
