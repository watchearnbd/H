package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.KnowledgeDao
import com.example.data.KnowledgeSeeder
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class KnowledgeDaoTest {
    private lateinit var db: AppDatabase
    private lateinit var dao: KnowledgeDao

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.knowledgeDao()
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun testGitaSearchQueries() = runBlocking {
        dao.insertAll(KnowledgeSeeder.initialData)
        
        val queries = listOf(
            "কর্মযোগ",
            "Karma Yoga",
            "ভক্তিযোগ",
            "Bhakti Yoga",
            "আত্মা",
            "Atman",
            "মোক্ষ",
            "Moksha",
            "গীতার ২য় অধ্যায়",
            "Chapter 2",
            "গায়ত্রী মন্ত্র",
            "Gayatri Mantra",
            "गायत्री मंत्र",
            "মহামৃত্যুঞ্জয় মন্ত্র",
            "Mahamrityunjaya Mantra",
            "কর্মযোগ শ্লোক",
            "Karma Yoga Shloka"
        )
        
        var failures = 0
        for (query in queries) {
            val results = dao.searchKnowledge(query)
            if (results.isEmpty()) {
                println("Query '$query' FAILED.")
                failures++
            } else {
                println("Query '$query' passed with ${results.size} results.")
            }
        }
        assertTrue("There were $failures failing queries", failures == 0)
    }
}
