package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedItemDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(savedItem: SavedItemEntity)

    @Query("DELETE FROM saved_items WHERE id = :id")
    suspend fun deleteById(id: String)
    
    @Query("SELECT * FROM saved_items ORDER BY updatedDate DESC")
    fun getAllSavedItems(): Flow<List<SavedItemEntity>>
    
    @Query("SELECT * FROM saved_items WHERE type = :type ORDER BY updatedDate DESC")
    fun getSavedItemsByType(type: String): Flow<List<SavedItemEntity>>

    @Query("SELECT * FROM saved_items WHERE title LIKE '%' || :query || '%' OR question LIKE '%' || :query || '%' OR answer LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' ORDER BY updatedDate DESC")
    fun searchSavedItems(query: String): Flow<List<SavedItemEntity>>
    
    @Query("SELECT * FROM saved_items WHERE id = :id LIMIT 1")
    suspend fun getSavedItemById(id: String): SavedItemEntity?
    
    @Query("SELECT * FROM saved_items WHERE id = :id LIMIT 1")
    fun observeSavedItemById(id: String): Flow<SavedItemEntity?>

    @Query("DELETE FROM saved_items")
    suspend fun deleteAllSavedItems()
}
