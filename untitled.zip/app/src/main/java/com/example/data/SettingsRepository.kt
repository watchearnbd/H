package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    
    companion object {
        val THEME_PREFERENCE = stringPreferencesKey("theme_preference")
        val LANGUAGE_PREFERENCE = stringPreferencesKey("language_preference")
        val DEFAULT_CHAT_MODE = stringPreferencesKey("default_chat_mode")
        val RESEARCH_BEHAVIOR = stringPreferencesKey("research_behavior")
        val SHOW_SOURCES = booleanPreferencesKey("show_sources")
        val SCRIPTURE_SOURCE_DISPLAY = booleanPreferencesKey("scripture_source_display")
        val VERIFICATION_BADGE_DISPLAY = booleanPreferencesKey("verification_badge_display")
        val TTS_ENABLED = booleanPreferencesKey("tts_enabled")
        val TTS_SPEED = floatPreferencesKey("tts_speed")
        val VOICE_INPUT = stringPreferencesKey("voice_input")
        val TEXT_SIZE = stringPreferencesKey("text_size")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val DAILY_DHARMA_REMINDER = booleanPreferencesKey("daily_dharma_reminder")
        val FESTIVAL_REMINDER = booleanPreferencesKey("festival_reminder")
        val CHAT_HISTORY_CONTROL = stringPreferencesKey("chat_history_control")
    }

    val themePreference: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[THEME_PREFERENCE] ?: "System"
    }

    val textSize: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[TEXT_SIZE] ?: "Medium"
    }

    val languagePreference: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[LANGUAGE_PREFERENCE] ?: "বাংলা"
    }

    val defaultChatMode: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[DEFAULT_CHAT_MODE] ?: "Normal Chat"
    }

    val researchBehavior: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[RESEARCH_BEHAVIOR] ?: "Balanced"
    }

    val showSources: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[SHOW_SOURCES] ?: true
    }

    val scriptureSourceDisplay: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[SCRIPTURE_SOURCE_DISPLAY] ?: true
    }

    val verificationBadgeDisplay: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[VERIFICATION_BADGE_DISPLAY] ?: true
    }

    val ttsEnabled: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[TTS_ENABLED] ?: true
    }

    val ttsSpeed: Flow<Float> = context.dataStore.data.map { preferences ->
        preferences[TTS_SPEED] ?: 1.0f
    }

    val voiceInput: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[VOICE_INPUT] ?: "Default"
    }
    
    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[NOTIFICATIONS_ENABLED] ?: true
    }

    val dailyDharmaReminder: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[DAILY_DHARMA_REMINDER] ?: true
    }

    val festivalReminder: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[FESTIVAL_REMINDER] ?: true
    }

    val chatHistoryControl: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[CHAT_HISTORY_CONTROL] ?: "Keep until I delete"
    }

    suspend fun setThemePreference(theme: String) {
        context.dataStore.edit { preferences ->
            preferences[THEME_PREFERENCE] = theme
        }
    }

    suspend fun setTextSize(size: String) {
        context.dataStore.edit { preferences ->
            preferences[TEXT_SIZE] = size
        }
    }

    suspend fun setLanguagePreference(language: String) {
        context.dataStore.edit { preferences ->
            preferences[LANGUAGE_PREFERENCE] = language
        }
    }

    suspend fun setDefaultChatMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[DEFAULT_CHAT_MODE] = mode
        }
    }

    suspend fun setResearchBehavior(behavior: String) {
        context.dataStore.edit { preferences ->
            preferences[RESEARCH_BEHAVIOR] = behavior
        }
    }

    suspend fun setShowSources(show: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[SHOW_SOURCES] = show
        }
    }

    suspend fun setScriptureSourceDisplay(show: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[SCRIPTURE_SOURCE_DISPLAY] = show
        }
    }

    suspend fun setVerificationBadgeDisplay(show: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[VERIFICATION_BADGE_DISPLAY] = show
        }
    }

    suspend fun setTtsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[TTS_ENABLED] = enabled
        }
    }

    suspend fun setTtsSpeed(speed: Float) {
        context.dataStore.edit { preferences ->
            preferences[TTS_SPEED] = speed
        }
    }

    suspend fun setVoiceInput(input: String) {
        context.dataStore.edit { preferences ->
            preferences[VOICE_INPUT] = input
        }
    }
    
    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[NOTIFICATIONS_ENABLED] = enabled
        }
    }

    suspend fun setDailyDharmaReminder(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[DAILY_DHARMA_REMINDER] = enabled
        }
    }

    suspend fun setFestivalReminder(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[FESTIVAL_REMINDER] = enabled
        }
    }

    suspend fun setChatHistoryControl(control: String) {
        context.dataStore.edit { preferences ->
            preferences[CHAT_HISTORY_CONTROL] = control
        }
    }
}
