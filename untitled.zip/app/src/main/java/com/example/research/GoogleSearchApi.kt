package com.example.research

import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GoogleCustomSearchResponse(
    val items: List<GoogleCustomSearchItem>? = null
)

@JsonClass(generateAdapter = true)
data class GoogleCustomSearchItem(
    val title: String?,
    val link: String?,
    val displayLink: String?,
    val snippet: String?
)

interface GoogleCustomSearchService {
    @GET("customsearch/v1")
    suspend fun search(
        @Query("q") query: String,
        @Query("key") apiKey: String,
        @Query("cx") cx: String
    ): GoogleCustomSearchResponse
}

object GoogleSearchRetrofit {
    private const val BASE_URL = "https://www.googleapis.com/"
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
        
    val service: GoogleCustomSearchService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
        retrofit.create(GoogleCustomSearchService::class.java)
    }
}
