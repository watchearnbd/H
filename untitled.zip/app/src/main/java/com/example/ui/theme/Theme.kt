package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = EditorialOrange200,
    onPrimary = EditorialSlate900,
    primaryContainer = Color(0xFFEA580C).copy(alpha = 0.3f), // EditorialOrange600 with alpha
    onPrimaryContainer = EditorialOrange100,
    secondary = Color(0xFF64748B), // EditorialSlate500
    onSecondary = Color.White,
    secondaryContainer = EditorialSlate700,
    onSecondaryContainer = EditorialSlate200,
    background = EditorialSlate900,
    onBackground = EditorialSlate50,
    surface = EditorialSlate800,
    onSurface = EditorialSlate50,
    surfaceVariant = EditorialSlate700,
    onSurfaceVariant = EditorialSlate200,
    error = Color(0xFFF87171),
    errorContainer = Color(0xFF7F1D1D),
    onError = Color.White,
    onErrorContainer = Color(0xFFFEE2E2),
    tertiary = Color(0xFFFBBF24),
    tertiaryContainer = Color(0xFF78350F),
    onTertiaryContainer = Color(0xFFFEF3C7)
)

private val LightColorScheme = lightColorScheme(
    primary = EditorialOrange600,
    onPrimary = Color.White,
    primaryContainer = EditorialOrange100,
    onPrimaryContainer = EditorialOrange600,
    secondary = EditorialSlate500,
    onSecondary = Color.White,
    secondaryContainer = EditorialSlate100,
    onSecondaryContainer = EditorialSlate900,
    background = EditorialBackground,
    onBackground = EditorialSlate900,
    surface = Color.White,
    onSurface = EditorialSlate900,
    surfaceVariant = EditorialSlate50,
    onSurfaceVariant = EditorialSlate500,
    error = Color(0xFFDC2626),
    errorContainer = Color(0xFFFEE2E2),
    onError = Color.White,
    onErrorContainer = Color(0xFF991B1B),
    tertiary = Color(0xFFD97706),
    tertiaryContainer = Color(0xFFFEF3C7),
    onTertiaryContainer = Color(0xFF92400E)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disable dynamic colors to enforce Editorial colors
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
