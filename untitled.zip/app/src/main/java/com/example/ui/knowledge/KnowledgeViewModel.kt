package com.example.ui.knowledge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.KnowledgeDao
import com.example.data.KnowledgeEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class KnowledgeViewModel(private val dao: KnowledgeDao) : ViewModel() {
    private val _knowledgeList = MutableStateFlow<List<KnowledgeEntity>>(emptyList())
    val knowledgeList: StateFlow<List<KnowledgeEntity>> = _knowledgeList.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    
    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    init {
        search("", "All")
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        search(query, _selectedCategory.value)
    }
    
    fun setCategory(category: String) {
        _selectedCategory.value = category
        search(_searchQuery.value, category)
    }

    private fun search(query: String, category: String) {
        viewModelScope.launch {
            val results = dao.searchKnowledge(query)
            if (category == "All") {
                _knowledgeList.value = results
            } else {
                _knowledgeList.value = results.filter { it.category.contains(category, ignoreCase = true) || it.tags.contains(category, ignoreCase = true) }
            }
        }
    }
}

class KnowledgeViewModelFactory(private val dao: KnowledgeDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(KnowledgeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return KnowledgeViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
