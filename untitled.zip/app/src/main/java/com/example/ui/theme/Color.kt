package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val EditorialBackground = Color(0xFFFDFBF7)
val EditorialOrange50 = Color(0xFFFFF7ED)
val EditorialOrange100 = Color(0xFFFFEDD5)
val EditorialOrange200 = Color(0xFFFED7AA)
val EditorialOrange600 = Color(0xFFEA580C)
val EditorialSlate50 = Color(0xFFF8FAFC)
val EditorialSlate100 = Color(0xFFF1F5F9)
val EditorialSlate200 = Color(0xFFE2E8F0)
val EditorialSlate400 = Color(0xFF94A3B8)
val EditorialSlate500 = Color(0xFF64748B)
val EditorialSlate700 = Color(0xFF334155)
val EditorialSlate800 = Color(0xFF1E293B)
val EditorialSlate900 = Color(0xFF0F172A)
val EditorialGreen500 = Color(0xFF22C55E)
