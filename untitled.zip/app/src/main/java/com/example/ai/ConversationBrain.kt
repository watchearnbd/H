package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi

@JsonClass(generateAdapter = true)
data class ConversationStateAnalysis(
    val currentTopic: String? = null,
    val previousTopic: String? = null,
    val userIntents: List<String> = emptyList(),
    val conversationGoal: String? = null,
    val importantEntities: List<String> = emptyList(),
    val referencedEntities: List<String> = emptyList(),
    val responseDepth: String = "MEDIUM",
    val userKnowledgeLevel: String = "BEGINNER",
    val detectedTone: String = "NEUTRAL",
    val resolvedQuery: String? = null,
    val clarificationNeeded: String? = null
)

class ConversationBrain {
    private val moshi = Moshi.Builder().build()
    private val adapter = moshi.adapter(ConversationStateAnalysis::class.java)

    suspend fun analyzeConversationState(query: String, history: List<ChatMessage>): ConversationStateAnalysis = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext ConversationStateAnalysis(resolvedQuery = query)
        }
        
        val recentHistory = history.takeLast(8).joinToString("\n") { 
            "${if (it.isUser) "User" else "AI"}: ${it.text.take(500)}"
        }
        
        val systemInstruction = """
            You are the "Conversation Brain" of Dharma AI.
            Analyze the user's latest query considering the recent chat history.
            
            1. INTENT DETECTION: Array of strings. Valid intents: GREETING, QUESTION, FOLLOW_UP, CLARIFICATION, REQUEST_FOR_EXAMPLE, REQUEST_FOR_SIMPLIFICATION, REQUEST_FOR_COMPARISON, REQUEST_FOR_STEPS, REQUEST_FOR_SOURCE, REQUEST_FOR_REFERENCE, REQUEST_FOR_MEANING, REQUEST_FOR_DEFINITION, REQUEST_FOR_RESEARCH, CASUAL_CONVERSATION, CORRECTION, DISAGREEMENT, FEEDBACK, UNKNOWN.
            2. CONTEXT RESOLUTION: If the query has pronouns ("এটা", "এর", "ওটা"), resolve them from history and provide the 'resolvedQuery'. Example: User says "এর অর্থ কী?" after AI talked about "গায়ত্রী মন্ত্র". resolvedQuery should be "গায়ত্রী মন্ত্রের অর্থ কী?". If no resolution needed, resolvedQuery = original query.
            3. AMBIGUITY CHECK: Only ask for clarification if the ambiguity significantly changes the meaning (e.g., "শক্তি" as Physics vs Hindu Goddess). Do NOT clarify if the intent is clear (e.g., "কর্মযোগ কী?"). If clarification needed, set 'clarificationNeeded' with a polite question in Bengali. Otherwise, set it to null.
            4. RESPONSE DEPTH: SHORT, MEDIUM, DETAILED, RESEARCH, STEP_BY_STEP.
            5. USER KNOWLEDGE LEVEL: BEGINNER, INTERMEDIATE, ADVANCED.
            6. TONE: CONFUSED, CURIOUS, FRUSTRATED, EXCITED, NEUTRAL.
            
            Return ONLY a valid JSON object matching this structure:
            {
                "currentTopic": "Topic or null",
                "previousTopic": "Topic or null",
                "userIntents": ["INTENT1", "INTENT2"],
                "conversationGoal": "Goal or null",
                "importantEntities": ["entity1"],
                "referencedEntities": ["resolved entity"],
                "responseDepth": "MEDIUM",
                "userKnowledgeLevel": "BEGINNER",
                "detectedTone": "NEUTRAL",
                "resolvedQuery": "The resolved query without ambiguity",
                "clarificationNeeded": "Clarification question or null"
            }
        """.trimIndent()
        
        val prompt = "Recent History:\n$recentHistory\n\nLatest User Query: $query"
        
        val request = GenerateContentRequest(
            contents = listOf(Content(role = "user", parts = listOf(Part(text = prompt)))),
            systemInstruction = Content(role = "system", parts = listOf(Part(text = systemInstruction))),
            generationConfig = GenerationConfig(responseMimeType = "application/json")
        )
        
        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (text != null) {
                return@withContext adapter.fromJson(text) ?: ConversationStateAnalysis(resolvedQuery = query)
            }
        } catch (e: Exception) {}
        
        return@withContext ConversationStateAnalysis(resolvedQuery = query)
    }
}
