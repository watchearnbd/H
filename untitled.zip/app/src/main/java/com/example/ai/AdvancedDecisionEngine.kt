package com.example.ai

import com.example.BuildConfig
import com.example.research.ResearchEngine
import com.example.research.ResearchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi

@JsonClass(generateAdapter = true)
data class SelfCheckAnalysis(
    val isValid: Boolean = true,
    val correctionsNeeded: String? = null,
    val recommendedFollowUps: List<String> = emptyList()
)

class AdvancedDecisionEngine(
    private val conversationBrain: ConversationBrain,
    private val researchEngine: ResearchEngine,
    private val aiProvider: AiProvider
) {
    private val moshi = Moshi.Builder().build()
    private val adapter = moshi.adapter(SelfCheckAnalysis::class.java)

    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {
        
        // 1. Intent + Context via ConversationBrain
        onProgress("🧠 Conversation State Analysis...")
        val stateAnalysis = conversationBrain.analyzeConversationState(userMessage, history)
        
        // 2. Ambiguity Check & Wrong Premise Check (from stateAnalysis)
        if (!stateAnalysis.clarificationNeeded.isNullOrBlank() && stateAnalysis.clarificationNeeded != "null") {
            return@withContext ChatMessage(isUser = false, text = stateAnalysis.clarificationNeeded)
        }
        
        val finalQuery = stateAnalysis.resolvedQuery ?: userMessage
        
        // 3. Answer Strategy Decision
        val strategy = decideAnswerStrategy(stateAnalysis)
        onProgress("💡 Strategy: \$strategy")
        
        val strategyPrompt = buildStrategyPrompt(stateAnalysis, strategy)
        val queryWithStrategy = "USER QUERY: \$finalQuery\n\n[CONVERSATION BRAIN DIRECTIVES (Do NOT show these to user)]\n\$strategyPrompt"
        
        // 4. Knowledge Availability Check & Research Decision
        // (Delegated partially to ResearchEngine, but informed by strategyPrompt)
        val apiHistory = history.map { Content(role = if (it.isUser) "user" else "model", parts = listOf(Part(text = it.text))) }
        
        // 5. Answer Generation
        
        val forceSkipResearch = strategy == "GREETING_RESPONSE" || strategy == "CLARIFICATION"
        val effectiveDeepResearch = if (forceSkipResearch) false else isDeepResearch
        var result = researchEngine.conductResearch(queryWithStrategy, apiHistory, effectiveDeepResearch, onProgress)
    
        
        // 6. Answer Self-Check
        onProgress("🛡️ Self-Check & Quality Verification...")
        val selfCheckResult = runSelfCheck(finalQuery, result.answer, stateAnalysis)
        
        // 7. Self-Correction
        var finalAnswer = result.answer
        if (!selfCheckResult.isValid && !selfCheckResult.correctionsNeeded.isNullOrBlank()) {
            onProgress("🔧 Self-Correcting...")
            try {
                finalAnswer = generateCorrection(finalQuery, result.answer, selfCheckResult.correctionsNeeded, history)
            } catch (e: Exception) {
                // Ignore correction if it fails due to auth or network
            }
        }
        
        // 8. Follow-Up Decision
        var followUps = result.suggestedQuestions
        if (selfCheckResult.recommendedFollowUps.isNotEmpty()) {
            followUps = selfCheckResult.recommendedFollowUps
        }
        val maxFollowUps = when (strategy) {
            "GREETING_RESPONSE", "CLARIFICATION", "UNKNOWN_KNOWLEDGE", "GIBBERISH" -> 0
            "SHORT", "DIRECT_ANSWER" -> 2
            "RESEARCH", "DETAILED_EXPLANATION" -> 4
            else -> 3
        }
        followUps = followUps.take(maxFollowUps)
        
        return@withContext ChatMessage(
            isUser = false, 
            text = finalAnswer, 
            localSources = result.localSources.map { "\${it.scripture} (\${it.reference})" }.filter { it.isNotBlank() }.distinct(),
            webSources = result.webSources,
            youtubeSources = result.youtubeSources,
            verificationStatus = result.verificationStatus,
            sourceMetadata = result.sourceMetadata,
            suggestedQuestions = followUps
        )
    }

    private fun decideAnswerStrategy(analysis: ConversationStateAnalysis): String {
        val intents = analysis.userIntents
        if (intents.contains("GREETING")) return "GREETING_RESPONSE"
        if (intents.contains("UNKNOWN") || intents.contains("GIBBERISH")) return "CLARIFICATION"
        if (intents.contains("REQUEST_FOR_EXAMPLE")) return "EXAMPLE"
        if (intents.contains("REQUEST_FOR_SIMPLIFICATION")) return "SIMPLIFIED_EXPLANATION"
        if (intents.contains("REQUEST_FOR_STEPS")) return "STEP_BY_STEP"
        if (intents.contains("REQUEST_FOR_RESEARCH") || intents.contains("REQUEST_FOR_SOURCE")) return "RESEARCH"
        if (intents.contains("REQUEST_FOR_COMPARISON")) return "COMPARISON"
        if (intents.contains("CORRECTION")) return "CORRECTION_RESPONSE"
        
        return when (analysis.responseDepth) {
            "SHORT" -> "DIRECT_ANSWER"
            "DETAILED" -> "DETAILED_EXPLANATION"
            "RESEARCH" -> "RESEARCH"
            else -> "CONTEXTUAL_ANSWER"
        }
    }

    private fun buildStrategyPrompt(analysis: ConversationStateAnalysis, strategy: String): String {
        return buildString {
            append("STRATEGY: \$strategy\n")
            append("INSTRUCTIONS:\n")
            append("- Target Audience Level: \${analysis.userKnowledgeLevel}\n")
            append("- Detected Tone: \${analysis.detectedTone}\n")
            
            when (strategy) {
                "GREETING_RESPONSE" -> append("- Give a warm, concise greeting. Do not preach.\n")
                "CLARIFICATION" -> append("- Politely ask what the user meant.\n")
                "EXAMPLE" -> append("- Provide a clear, practical, real-life example.\n")
                "SIMPLIFIED_EXPLANATION" -> append("- Use an analogy. Avoid complex jargon. Explain like they are 10 years old.\n")
                "STEP_BY_STEP" -> append("- Use bullet points or numbered lists. Be methodical.\n")
                "COMPARISON" -> append("- Compare the subjects clearly. Highlight similarities and differences.\n")
                "RESEARCH" -> append("- Use structured data, cite sources, verify claims.\n")
                "CORRECTION_RESPONSE" -> append("- Acknowledge user's correction empathetically. Say 'বুঝতে পেরেছি'.\n")
                "DIRECT_ANSWER" -> append("- Be concise and straight to the point.\n")
                "DETAILED_EXPLANATION" -> append("- Expand on concepts thoroughly but maintain natural tone.\n")
                else -> append("- Provide a well-rounded contextual answer.\n")
            }
            
            append("\nCRITICAL RULES:\n")
            append("- If asked about '25th chapter of Gita' or similar wrong premises, CORRECT the premise immediately.\n")
            append("- NEVER hallucinate chapter/verse numbers, URLs, or mantras.\n")
            append("- Avoid robotic repetition (don't always start with 'অবশ্যই').\n")
            append("- Answer General Knowledge normally (e.g. Earth's biggest ocean) without saying you only know Dharma.\n")
            append("- CORE RULE: Accuracy > Confidence. Verified Knowledge > Guessing. Truth > Speed.\n")
            append("- Never invent scripture names, chapters, verses, Sanskrit texts, mantras, shlokas, sources, authors, historical events, citations, or URLs.\n")
            append("- Use natural Bengali, avoid robotic repetitions. Adjust length based on query.\n")
            append("- Do not force one tradition as the absolute truth if Vaishnava, Shaiva, Shakta, Smarta, Vedanta, or Yoga differ.\n")
            append("- For mantras/shlokas, output in this exact format if verified data exists: 🕉️ পাঠ, 📖 শাস্ত্রীয় উৎস, 📍 Reference, 🔤 উচ্চারণ, 📝 বাংলা অর্থ, 💡 সহজ ব্যাখ্যা, 🔎 Verification, 📚 Source. Do not fabricate unverified parts.\n")
            append("- Be respectful towards all deities, scriptures, beliefs, and communities.\n")
            append("- If completely unknown, say 'এই বিষয়টি সম্পর্কে আমার কাছে এখন নির্ভরযোগ্য তথ্য পর্যাপ্ত নেই। অনুমান করে ভুল তথ্য দিতে চাই না।'\n")
        }
    }

    private suspend fun runSelfCheck(query: String, answer: String, analysis: ConversationStateAnalysis): SelfCheckAnalysis {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return SelfCheckAnalysis()
        }
        
        val systemInstruction = """
            You are the "Answer Self-Check Engine" for Dharma AI.
            Analyze the AI's generated answer against the User Query.
            
            Check the following:
            A. Did it answer the user's actual question?
            B. Did it invent a fake scripture, mantra, or URL?
            C. Did it claim to do Web Research when it didn't?
            D. Is it unnecessarily long for a simple query?
            E. Does it sound robotic (e.g. starts with 'অবশ্যই, আপনার উত্তর হলো...')?
            F. Did it fail to detect a wrong premise (e.g. 25th chapter of Gita)?
            
            If the answer violates rules, set isValid=false and provide specific instructions in 'correctionsNeeded' (e.g., "Remove the fake URL. Fix the robotic intro. Correct the chapter count to 18.").
            Otherwise, set isValid=true.
            
            Also, provide 0-5 'recommendedFollowUps' based on the conversation.
            
            Return ONLY a valid JSON object:
            {
                "isValid": true/false,
                "correctionsNeeded": "string or null",
                "recommendedFollowUps": ["Q1", "Q2"]
            }
        """.trimIndent()
        
        val prompt = "User Query: \$query\n\nAI Answer: \$answer"
        
        val request = com.example.ai.GenerateContentRequest(
            contents = listOf(Content(role = "user", parts = listOf(Part(text = prompt)))),
            systemInstruction = Content(role = "system", parts = listOf(Part(text = systemInstruction))),
            generationConfig = com.example.ai.GenerationConfig(responseMimeType = "application/json")
        )
        
        try {
            val response = com.example.ai.RetrofitClient.service.generateContent(apiKey, request)
            val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (text != null) {
                return adapter.fromJson(text) ?: SelfCheckAnalysis()
            }
        } catch (e: Exception) {}
        
        return SelfCheckAnalysis()
    }

    private suspend fun generateCorrection(query: String, originalAnswer: String, corrections: String, history: List<ChatMessage>): String {
        val prompt = "USER QUERY: \$query\n\nORIGINAL DRAFT:\n\$originalAnswer\n\nCRITIQUE / CORRECTIONS REQUIRED:\n\$corrections\n\nRewrite the final answer incorporating these corrections. ONLY output the rewritten answer, nothing else."
        return aiProvider.generateResponse(history.map { Content(role = if (it.isUser) "user" else "model", parts = listOf(Part(text = it.text))) } + Content(role = "user", parts = listOf(Part(text = prompt))), null)
    }
}
