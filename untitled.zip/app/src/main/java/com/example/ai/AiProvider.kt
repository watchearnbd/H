package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi

@JsonClass(generateAdapter = true)
data class QueryAnalysis(
    val needsWebSearch: Boolean = false,
    val webSearchQuery: String? = null,
    val needsYouTube: Boolean = false,
    val youtubeSearchQuery: String? = null,
    val category: String? = null
)

interface AiProvider {
    suspend fun generateResponse(history: List<Content>, systemInstruction: String?): String
    suspend fun analyzeQuery(query: String): QueryAnalysis
}

class GeminiAiProvider : AiProvider {
    private val moshi = Moshi.Builder().build()
    private val adapter = moshi.adapter(QueryAnalysis::class.java)

    override suspend fun generateResponse(history: List<Content>, systemInstruction: String?): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            throw Exception("Gemini API Key is missing.")
        }
        
        val sysInstruct = systemInstruction?.let { 
            Content(role = "system", parts = listOf(Part(text = it))) 
        }

        val request = GenerateContentRequest(
            contents = history,
            systemInstruction = sysInstruct
        )
        
        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            if (response.error != null) {
                throw Exception("API Error: ${response.error}")
            }
            
            return@withContext response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: throw Exception("Empty response from AI")
        } catch (e: retrofit2.HttpException) {
            if (e.code() == 401 || e.code() == 403 || e.code() == 400) {
                throw Exception("AUTH_ERROR")
            }
            throw e
        } catch (e: Exception) {
            val msg = e.message ?: ""
            if (msg.contains("401") || msg.contains("403") || msg.contains("API key")) {
                throw Exception("AUTH_ERROR")
            }
            throw e
        }
    }

    override suspend fun analyzeQuery(query: String): QueryAnalysis = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext QueryAnalysis(false, null, false, null, "UNKNOWN")
        }
        
        val systemInstruction = """
                        You are a query analyzer. Analyze the user's query and decide if web search or YouTube search is needed.
            - Web search: needed for current dates, deep scriptural references, origins, comparisons, or complex unknown topics.
            - Do NOT use web search for basic greetings (Hi, Hello), gibberish, casual conversation, simple general knowledge, or short follow-ups (e.g. "কেন?", "কীভাবে?").
            - YouTube search: needed ONLY if the user explicitly asks for a video, recitation, pronunciation, lecture, or visual guide.
            Classify the question into one of: GENERAL_KNOWLEDGE, DHARMA, SCRIPTURE, MANTRA, SHLOKA, PUJA, FESTIVAL, PHILOSOPHY, SCIENCE, HISTORY, EDUCATION, TECHNOLOGY, LANGUAGE, MATH, CASUAL_CONVERSATION, AMBIGUOUS, UNKNOWN.
            Return ONLY a valid JSON object matching this structure:
            {"needsWebSearch": boolean, "webSearchQuery": "english search string or null", "needsYouTube": boolean, "youtubeSearchQuery": "search string or null", "category": "CLASSIFICATION_HERE"}
        """.trimIndent()
        
        val request = GenerateContentRequest(
            contents = listOf(Content(role = "user", parts = listOf(Part(text = query)))),
            systemInstruction = Content(role = "system", parts = listOf(Part(text = systemInstruction))),
            generationConfig = GenerationConfig(responseMimeType = "application/json")
        )
        
        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (text != null) {
                return@withContext adapter.fromJson(text) ?: QueryAnalysis(false, null, false, null, "UNKNOWN")
            }
        } catch (e: Exception) {}
        
        return@withContext QueryAnalysis(false, null, false, null, "UNKNOWN")
    }
}
