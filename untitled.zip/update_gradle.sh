sed -i 's/\[versions\]/\[versions\]\nserialization = "1.6.3"\nretrofitSerialization = "1.0.0"\n/g' gradle/libs.versions.toml
sed -i 's/\[libraries\]/\[libraries\]\nkotlinx-serialization-json = { group = "org.jetbrains.kotlinx", name = "kotlinx-serialization-json", version.ref = "serialization" }\nretrofit2-kotlinx-serialization-converter = { group = "com.jakewharton.retrofit", name = "retrofit2-kotlinx-serialization-converter", version.ref = "retrofitSerialization" }\n/g' gradle/libs.versions.toml

sed -i 's/alias(libs.plugins.google.services) apply false/alias(libs.plugins.google.services) apply false\n  kotlin("plugin.serialization") version "1.9.0" apply false/g' build.gradle.kts

sed -i 's/alias(libs.plugins.google.services)/alias(libs.plugins.google.services)\n  kotlin("plugin.serialization")/g' app/build.gradle.kts

sed -i 's/\/\/ implementation(libs.androidx.navigation.compose)/implementation(libs.androidx.navigation.compose)/g' app/build.gradle.kts
sed -i 's/implementation(libs.retrofit)/implementation(libs.retrofit)\n  implementation(libs.kotlinx.serialization.json)\n  implementation(libs.retrofit2.kotlinx.serialization.converter)/g' app/build.gradle.kts

sed -i 's/<manifest xmlns:android="http:\/\/schemas.android.com\/apk\/res\/android"/<manifest xmlns:android="http:\/\/schemas.android.com\/apk\/res\/android"\n    xmlns:tools="http:\/\/schemas.android.com\/tools">\n\n    <uses-permission android:name="android.permission.INTERNET" \/>/g' app/src/main/AndroidManifest.xml
