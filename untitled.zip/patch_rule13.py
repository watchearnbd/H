import os

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    text = f.read()

text = text.replace(
    'append("13. SUGGESTED QUESTIONS (CRITICAL): At the VERY END of your response, you MUST provide 3 to 5 highly relevant, context-aware follow-up questions for the user. Do NOT invent fake scripture references in these suggestions. Append them exactly in this format:\\n\\n---SUGGESTED_QUESTIONS---\\n1. [Question 1]\\n2. [Question 2]\\n3. [Question 3]\\n")',
    'append("13. SUGGESTED QUESTIONS (CRITICAL): At the VERY END of your response, you MUST provide 3 to 5 highly relevant, context-aware follow-up questions for the user. Do NOT invent fake scripture references in these suggestions. For ambiguous or unknown/gibberish questions, you MAY skip suggesting follow-ups. Append them exactly in this format:\\n\\n---SUGGESTED_QUESTIONS---\\n1. [Question 1]\\n2. [Question 2]\\n3. [Question 3]\\n")'
)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(text)

