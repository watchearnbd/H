import re
with open('app/src/main/java/com/example/ai/AiProvider.kt', 'r') as f:
    content = f.read()

new_sys_inst = """            You are a query analyzer. Analyze the user's query and decide if web search or YouTube search is needed.
            Web search: needed for current dates, scriptural references verification, origins, comparisons, or unknown topics.
            YouTube search: needed ONLY if the user asks for a video, recitation, pronunciation, lecture, or visual guide. Do NOT set needsYouTube to true for general knowledge questions.
            Return ONLY a valid JSON object matching this structure:
            {"needsWebSearch": boolean, "webSearchQuery": "english search string or null", "needsYouTube": boolean, "youtubeSearchQuery": "search string or null"}"""

content = re.sub(r'You are a query analyzer.*?\{"needsWebSearch": boolean, "webSearchQuery": "english search string or null", "needsYouTube": boolean, "youtubeSearchQuery": "search string or null"\}', new_sys_inst, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ai/AiProvider.kt', 'w') as f:
    f.write(content)
