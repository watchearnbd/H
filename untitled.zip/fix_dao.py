with open('app/src/main/java/com/example/data/KnowledgeDao.kt', 'r') as f:
    content = f.read()

old_query = """        OR verse LIKE '%' || :query || '%'
    \"\"\")"""

new_query = """        OR verse LIKE '%' || :query || '%'
        OR deity LIKE '%' || :query || '%'
        OR traditionalPractice LIKE '%' || :query || '%'
        OR regionalVariation LIKE '%' || :query || '%'
        OR significance LIKE '%' || :query || '%'
        OR materials LIKE '%' || :query || '%'
        OR historicalContext LIKE '%' || :query || '%'
    \"\"\")"""

content = content.replace(old_query, new_query)

with open('app/src/main/java/com/example/data/KnowledgeDao.kt', 'w') as f:
    f.write(content)
