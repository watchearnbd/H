with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if line.strip().startswith('finalAnswerText = "⚠️ Network Error / Offline Mode'):
        # Fix the unescaped newlines by finding the lines that make up the broken string
        pass

# A simpler way: we know lines 151-156 are broken. We will just rewrite them.
new_lines = lines[:150]
new_lines.append('                finalAnswerText = "⚠️ Network Error / Offline Mode: ইন্টারনেট সংযোগ না থাকায় AI বিশ্লেষণ সম্ভব হচ্ছে না। নিচে Local Knowledge Base থেকে প্রাপ্ত সরাসরি তথ্য দেওয়া হলো:\\n\\n" + localResults.joinToString("\\n\\n") { "📌 " + it.title + "\\n" + it.content }\n')
new_lines.extend(lines[156:])

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.writelines(new_lines)
