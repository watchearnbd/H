import os

with open('app/src/main/java/com/example/ui/chat/ChatViewModel.kt', 'r') as f:
    text = f.read()

text = text.replace(
    'import com.example.ai.AiRepository',
    'import com.example.ai.AiRepository\nimport com.example.ai.ConversationBrain'
)

text = text.replace(
    'class ChatViewModel(\n    private val repository: AiRepository,',
    'class ChatViewModel(\n    private val conversationBrain: ConversationBrain,\n    private val repository: AiRepository,'
)

text = text.replace(
    'val responseMsg = repository.getAiResponse(question, _messages.value.dropLast(1), _isDeepResearch.value) { progressMsg ->',
    'val responseMsg = conversationBrain.processConversation(question, _messages.value.dropLast(1), _isDeepResearch.value) { progressMsg ->'
)

text = text.replace(
    'class ChatViewModelFactory(\n    private val repository: AiRepository,',
    'class ChatViewModelFactory(\n    private val conversationBrain: ConversationBrain,\n    private val repository: AiRepository,'
)

text = text.replace(
    'return ChatViewModel(repository, chatSessionDao) as T',
    'return ChatViewModel(conversationBrain, repository, chatSessionDao) as T'
)

with open('app/src/main/java/com/example/ui/chat/ChatViewModel.kt', 'w') as f:
    f.write(text)

