import os

def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        f.write(content.strip() + '\n')

write_file('app/src/main/java/com/example/ui/chat/ChatScreen.kt', """
package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val messages by viewModel.messages.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val isDeepResearch by viewModel.isDeepResearch.collectAsState()

    var textState by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        TopAppBar(
            title = { Text("Dharma AI", fontWeight = FontWeight.Bold) },
            actions = {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 8.dp)) {
                    Text(if (isDeepResearch) "Deep Research" else "Normal", fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp))
                    Switch(
                        checked = isDeepResearch,
                        onCheckedChange = { viewModel.toggleDeepResearch(it) }
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(messages) { message ->
                if (message.isUser) {
                    UserMessageCard(message.text)
                } else {
                    AiMessageCard(message)
                }
            }
            if (uiState is ChatUiState.Loading) {
                item {
                    LoadingIndicator((uiState as ChatUiState.Loading).progressMessage)
                }
            }
            if (uiState is ChatUiState.Error) {
                item {
                    ErrorIndicator((uiState as ChatUiState.Error).message) { viewModel.retry() }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = textState,
                onValueChange = { textState = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("প্রশ্ন করুন...") },
                shape = RoundedCornerShape(24.dp),
                enabled = uiState !is ChatUiState.Loading
            )
            Spacer(modifier = Modifier.width(8.dp))
            FloatingActionButton(
                onClick = {
                    if (textState.isNotBlank()) {
                        viewModel.sendMessage(textState)
                        textState = ""
                    }
                },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Send")
            }
        }
    }
}

@Composable
fun UserMessageCard(text: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Box(
            modifier = Modifier
                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp, 16.dp, 0.dp, 16.dp))
                .padding(16.dp)
                .widthIn(max = 280.dp)
        ) {
            Text(text, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}

@Composable
fun AiMessageCard(message: com.example.ai.ChatMessage) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Column(
            modifier = Modifier
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp, 16.dp, 16.dp, 0.dp))
                .padding(16.dp)
                .widthIn(max = 320.dp)
        ) {
            Text(message.text, color = MaterialTheme.colorScheme.onSurfaceVariant)
            
            if (message.localSources.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Local Sources: ${message.localSources.joinToString()}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }
            if (message.webSources.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("📚 Web Sources:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                message.webSources.forEach { w ->
                    Text("- ${w.domain}: ${w.title}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                }
            }
            if (message.youtubeSources.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("▶️ YouTube Videos:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                message.youtubeSources.forEach { y ->
                    Text("- ${y.channelTitle}: ${y.title}", fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary)
                }
            }
        }
    }
}

@Composable
fun LoadingIndicator(message: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(16.dp)) {
        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
        Spacer(modifier = Modifier.width(16.dp))
        Text(message, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
    }
}

@Composable
fun ErrorIndicator(message: String, onRetry: () -> Unit) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Error: $message", color = MaterialTheme.colorScheme.error)
        TextButton(onClick = onRetry) {
            Text("Retry")
        }
    }
}
""")

write_file('app/src/main/java/com/example/MainActivity.kt', """
package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ai.AiRepository
import com.example.ai.GeminiAiProvider
import com.example.data.AppDatabase
import com.example.data.KnowledgeSeeder
import com.example.research.ResearchEngine
import com.example.research.WebSearchProvider
import com.example.research.YouTubeSearchProvider
import com.example.ui.chat.ChatScreen
import com.example.ui.chat.ChatViewModel
import com.example.ui.chat.ChatViewModelFactory
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        GlobalScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(applicationContext)
            val count = db.knowledgeDao().getKnowledgeCount()
            if (count == 0) {
                db.knowledgeDao().insertAll(KnowledgeSeeder.initialData)
            }
        }
        
        setContent {
            MyApplicationTheme(darkTheme = true) { 
                val navController = rememberNavController()
                
                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Chat, contentDescription = "Chat") },
                                label = { Text("Chat") },
                                selected = true,
                                onClick = { navController.navigate("chat") { launchSingleTop = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Favorite, contentDescription = "Favorites") },
                                label = { Text("Favs") },
                                selected = false,
                                onClick = { navController.navigate("favorites") { launchSingleTop = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.History, contentDescription = "History") },
                                label = { Text("History") },
                                selected = false,
                                onClick = { navController.navigate("history") { launchSingleTop = true } }
                            )
                        }
                    }
                ) { paddingValues ->
                    NavHost(
                        navController = navController,
                        startDestination = "chat",
                        modifier = Modifier.padding(paddingValues)
                    ) {
                        composable("chat") {
                            val context = LocalContext.current
                            val db = AppDatabase.getDatabase(context)
                            val aiProvider = GeminiAiProvider()
                            val webSearchProvider = WebSearchProvider()
                            val youtubeSearchProvider = YouTubeSearchProvider()
                            val researchEngine = ResearchEngine(db.knowledgeDao(), webSearchProvider, youtubeSearchProvider, aiProvider)
                            val repository = AiRepository(researchEngine)
                            
                            val viewModel: ChatViewModel = viewModel(
                                factory = ChatViewModelFactory(repository)
                            )
                            
                            ChatScreen(viewModel = viewModel)
                        }
                        composable("favorites") { DummyScreen("Favorites") }
                        composable("history") { DummyScreen("History") }
                    }
                }
            }
        }
    }
}

@Composable
fun DummyScreen(title: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = title, style = MaterialTheme.typography.headlineMedium)
    }
}
""")
