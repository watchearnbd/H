with open('app/src/main/java/com/example/data/KnowledgeSeeder.kt', 'r') as f:
    content = f.read()

content = content.replace('"গীতা, অধ্যায় ২, সাংখ্য যোগ', '"গীতা, অধ্যায় ২, গীতার ২য় অধ্যায়, সাংখ্য যোগ')

with open('app/src/main/java/com/example/data/KnowledgeSeeder.kt', 'w') as f:
    f.write(content)
