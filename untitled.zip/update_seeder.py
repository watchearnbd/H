import re

with open('seeder_dump.txt', 'r') as f:
    content = f.read()

# Replacement for Gayatri Mantra
gayatri_old = r'KnowledgeEntity\(\s*title = "গায়ত্রী মন্ত্র".*?tags = "গায়ত্রী, মন্ত্র, সূর্য, বৈদিক, প্রার্থনা, Gayatri"\s*\)'
gayatri_new = """KnowledgeEntity(
            title = "গায়ত্রী মন্ত্র",
            category = "Mantra",
            subcategory = "Vedic Mantra",
            scripture = "ঋগ্বেদ",
            reference = "৩.৬২.১০",
            sanskritText = "ॐ भूर्भुवः स्वः तत्सवितुर्वरेण्यं भर्गो देवस्य धीमहि धियो यो नः प्रचोदयात् ॥",
            transliteration = "oṃ bhūr bhuvaḥ svaḥ tat savitur vareṇyaṃ bhargo devasya dhīmahi dhiyo yo naḥ pracodayāt",
            banglaMeaning = "ওঁ (পরমেশ্বর), যিনি ভূঃ (পৃথিবী), ভুবঃ (অন্তরীক্ষ) এবং স্বঃ (স্বর্গ)-এ ব্যাপ্ত, সেই সবিতা (সূর্যদেব বা স্রষ্টা)-র বরণীয় তেজ আমরা ধ্যান করি। তিনি আমাদের বুদ্ধিকে (সৎপথে) চালিত করুন।",
            content = "ওঁ ভূর্ভুবঃ স্বঃ তৎ সবিতুর্বরেণ্যং ভর্গো দেবস্য ধীমহি ধিয়ো য়ো নঃ প্রচোদয়াৎ।",
            explanation = "এটি অন্যতম পবিত্র বৈদিক মন্ত্র। আমরা সেই পরমেশ্বরের তেজ ধ্যান করি, যিনি আমাদের বুদ্ধিকে সঠিক পথে চালিত করেন।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গায়ত্রী মন্ত্র, Gayatri Mantra, गायत्री मंत्र, সূর্য, বৈদিক, প্রার্থনা",
            language = "Bengali, Sanskrit"
        )"""

# Replacement for Mahamrityunjaya
mahamrityunjaya_old = r'KnowledgeEntity\(\s*title = "মহামৃত্যুঞ্জয় মন্ত্র".*?tags = "মৃত্যুঞ্জয়, শিব, মন্ত্র, মহাদেব, ত্র্যম্বক, Mahamrityunjaya"\s*\)'
mahamrityunjaya_new = """KnowledgeEntity(
            title = "মহামৃত্যুঞ্জয় মন্ত্র",
            category = "Mantra",
            subcategory = "Shiva Mantra",
            scripture = "ঋগ্বেদ",
            reference = "৭.৫৯.১২",
            sanskritText = "ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम्। उर्वारुकमिव बन्धनान् मृत्योर्मुक्षीय मामृतात्॥",
            transliteration = "oṃ tryambakaṃ yajāmahe sugandhiṃ puṣṭivardhanam, urvārukamiva bandhanān mṛtyor mukṣīya māmṛtāt",
            banglaMeaning = "আমরা ত্রিনেত্র শিবের আরাধনা করি, যিনি সুগন্ধি ও পুষ্টিদাতা। শশা যেমন বোঁটা থেকে মুক্ত হয়, তেমনি তিনি যেন আমাদের মৃত্যু থেকে মুক্ত করেন এবং অমরত্ব প্রদান করেন।",
            content = "ওঁ ত্র্যম্বকং যজামহে সুগন্ধিং পুষ্টিবর্ধনম্। উর্বারুকমিব বন্ধনান্ মৃত্যোর্মুক্ষীয় মামৃতাৎ।।",
            explanation = "এটি ভগবান শিবের একটি অত্যন্ত শক্তিশালী মন্ত্র যা অকাল মৃত্যু থেকে রক্ষা পেতে এবং সুস্বাস্থ্য ও মোক্ষ লাভের জন্য জপ করা হয়।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "মহামৃত্যুঞ্জয় মন্ত্র, Mahamrityunjaya Mantra, महामृत्युंजय मंत्र, শিব, মহাদেব, ত্র্যম্বক, Shiva Mantra",
            language = "Bengali, Sanskrit"
        )"""

shloka_new = """,
        KnowledgeEntity(
            title = "কর্মযোগ শ্লোক (Karma Yoga Shloka)",
            category = "Shloka",
            subcategory = "Karma Yoga",
            scripture = "ভগবদ্গীতা",
            chapter = "2",
            verse = "47",
            reference = "অধ্যায় ২, শ্লোক ৪৭",
            sanskritText = "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन।\\nमा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥",
            transliteration = "karmaṇyevādhikāraste mā phaleṣu kadācana\\nmā karmaphalaheturbhūrmā te saṅgo'stvakarmani",
            banglaMeaning = "কর্মে তোমার অধিকার আছে, কিন্তু কর্মফলে কখনোই তোমার অধিকার নেই। তুমি নিজেকে কর্মফলের কারণ ভেবো না, আবার কর্মত্যাগেও যেন তোমার আসক্তি না হয়।",
            content = "কর্মণ্যেवाधिकारस्ते मा फलेषु कदाचन। મા কর্মফলহেতুর্ভூர்মा তে সङ्গোহস্ত্বকর্মণি।।",
            explanation = "এটি নিষ্কাম কর্মের মূল ভিত্তি। ফলাফল ঈশ্বরের হাতে ছেড়ে দিয়ে কেবল নিজের কর্তব্যটুকু নিষ্ঠার সাথে পালন করার নির্দেশ দেওয়া হয়েছে।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "কর্মযোগ শ্লোক, Karma Yoga Shloka, कर्मयोग श्लोक, গীতা, নিষ্কাম কর্ম, Bhagavad Gita, Chapter 2",
            language = "Bengali, Sanskrit"
        )"""

content = re.sub(gayatri_old, gayatri_new, content, flags=re.DOTALL)
content = re.sub(mahamrityunjaya_old, mahamrityunjaya_new, content, flags=re.DOTALL)

# Insert the new shloka before the Gita stuff starts (or at the end of the initial list before Arjuna Visada Yoga)
arjuna_old = r'KnowledgeEntity\(\s*title = "অর্জুন বিষাদ যোগ'
content = re.sub(arjuna_old, shloka_new.lstrip(',') + ',\n        KnowledgeEntity(\n            title = "অর্জুন বিষাদ যোগ', content, count=1)


with open('app/src/main/java/com/example/data/KnowledgeSeeder.kt', 'w') as f:
    f.write(content)

print("Updated KnowledgeSeeder.kt")
