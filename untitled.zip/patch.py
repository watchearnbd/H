import os

with open('app/src/main/java/com/example/ai/AiProvider.kt', 'r') as f:
    text = f.read()

text = text.replace(
    'Web search: needed for current dates, scriptural references verification, origins, comparisons, or unknown topics.\n            YouTube search: needed ONLY if the user asks for a video, recitation, pronunciation, lecture, or visual guide. Do NOT set needsYouTube to true for general knowledge questions.',
    '- Web search: needed for current dates, deep scriptural references, origins, comparisons, or complex unknown topics.\n            - Do NOT use web search for basic greetings (Hi, Hello), gibberish, casual conversation, simple general knowledge, or short follow-ups (e.g. "কেন?", "কীভাবে?").\n            - YouTube search: needed ONLY if the user explicitly asks for a video, recitation, pronunciation, lecture, or visual guide.'
)

with open('app/src/main/java/com/example/ai/AiProvider.kt', 'w') as f:
    f.write(text)


with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    r_text = f.read()

r_text = r_text.replace(
    'append("You are Dharma AI, a Research-Based Hindu Dharma AI Assistant. Answer purely in Bengali. Current Date: $todayDate.\\n")',
    'append("You are Dharma AI, an intelligent, helpful, and context-aware AI Assistant. While your primary expertise is Hindu Dharma, Philosophy, and Scriptures, you MUST also answer general knowledge, science, history, daily life, and other non-religious questions concisely and accurately if you know the answer. Adapt to the user\'s language, but default to Bengali. Current Date: $todayDate.\\n")'
)

new_rules = """            append("14. UNIVERSAL KNOWLEDGE: Answer general knowledge questions (e.g., 'পৃথিবীর সবচেয়ে বড় মহাসাগর কোনটি?') concisely and accurately without claiming you only know Dharma.\\n")
            append("15. UNCERTAINTY & HALLUCINATION PREVENTION: If unsure or lacking sources, DO NOT GUESS. State 'এই তথ্যটি সম্পর্কে আমি পুরোপুরি নিশ্চিত নই।' or 'এই বিষয়টি সম্পর্কে আমার কাছে এই মুহূর্তে নির্ভরযোগ্য তথ্য নেই।'\\n")
            append("16. AMBIGUITY, GIBBERISH & TYPOS: Clarify ambiguous questions (e.g. 'শক্তি' could mean Physics Energy or Hindu Shakti). Tolerate typos (e.g., 'গিতা ২ অধ্যায়' -> 'ভগবদ্গীতার দ্বিতীয় অধ্যায়'). If gibberish (e.g., 'asdfgh'), respond: 'আমি আপনার কথাটা পুরোপুরি বুঝতে পারিনি। একটু অন্যভাবে লিখবেন?'\\n")
            append("17. WRONG PREMISE: Do NOT accept false premises. E.g., if asked 'What is in the 25th chapter of Gita?', explicitly correct that Gita has only 18 chapters.\\n")
            append("18. CONVERSATIONAL TONE & LANGUAGE: Be natural, clear, and human-like. Don't be robotic. Do not force rigid formats on simple questions.\\n")
"""

r_text = r_text.replace(
    'append("13. SUGGESTED QUESTIONS (CRITICAL): At the VERY END of your response, you MUST provide 3 to 5 highly relevant, context-aware follow-up questions for the user. Do NOT invent fake scripture references in these suggestions. Append them exactly in this format:\\n\\n---SUGGESTED_QUESTIONS---\\n1. [Question 1]\\n2. [Question 2]\\n3. [Question 3]\\n")',
    'append("13. SUGGESTED QUESTIONS (CRITICAL): At the VERY END of your response, you MUST provide 3 to 5 highly relevant, context-aware follow-up questions for the user. Do NOT invent fake scripture references in these suggestions. Append them exactly in this format:\\n\\n---SUGGESTED_QUESTIONS---\\n1. [Question 1]\\n2. [Question 2]\\n3. [Question 3]\\n")\n' + new_rules
)

r_text = r_text.replace(
    'append("\\nNo exact matching records found in the Local Knowledge Base. Answer respectfully from your general verified Hindu Dharma knowledge, but explicitly mention: \'এই তথ্যের নির্দিষ্ট শাস্ত্রীয় reference Knowledge Base-এ পাওয়া যায়নি।\'\\n")',
    'append("\\nNo exact matching records found in the Local Knowledge Base. If it is a Dharma-related question, answer from your general verified knowledge but mention: \'এই তথ্যের নির্দিষ্ট শাস্ত্রীয় reference Knowledge Base-এ পাওয়া যায়নি।\'. If it is a general knowledge question (science, history, etc.), just answer it normally without mentioning the Knowledge Base.\\n")'
)

r_text = r_text.replace(
    'append("4. Use ONLY the provided Local Knowledge Database context to answer if no web results are provided.\\n")',
    'append("4. Use the provided Local Knowledge Database context if available. If it is a general question, use your general verified AI knowledge.\\n")'
)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(r_text)
