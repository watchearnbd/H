# ভয়েস জেনারেটর — GitHub এ আপলোড করে APK টেস্ট বিল্ড করার গাইড

এই প্রজেক্টে (`com.aistudio.voicegen.bqwlxz`) আগে থেকে কোনো `gradlew` ফাইল বা
`.github/workflows` ছিল না, তাই সরাসরি GitHub Actions দিয়ে বিল্ড করা যাচ্ছিল না।
আমি একটি ওয়ার্কফ্লো ফাইল (`.github/workflows/build-debug-apk.yml`) যোগ করে দিয়েছি,
যেটা push করলেই বা ম্যানুয়ালি রান করলেই স্বয়ংক্রিয়ভাবে একটি **Debug APK** বানিয়ে দেবে।

---

## ধাপ ১: GitHub রিপোজিটরি তৈরি করা

1. GitHub এ লগইন করে **New repository** এ ক্লিক করো।
2. নাম দাও, উদাহরণ: `voice-generator-app`
3. Public বা Private যেকোনোটা রাখতে পারো (README/gitignore যোগ করার দরকার নেই, প্রজেক্টে আগে থেকেই আছে)।
4. **Create repository** চাপো।

## ধাপ ২: প্রজেক্ট আপলোড করা

টার্মিনাল থেকে (এই ফোল্ডারের ভেতরে গিয়ে):

```bash
git init
git add .
git commit -m "Initial commit: Voice Generator app"
git branch -M main
git remote add origin https://github.com/<তোমার-ইউজারনেম>/voice-generator-app.git
git push -u origin main
```

> এখানে `<তোমার-ইউজারনেম>` জায়গায় নিজের GitHub ইউজারনেম বসাও।

## ধাপ ৩: (ঐচ্ছিক) আসল Gemini API Key যোগ করা

এই অ্যাপ চালাতে `GEMINI_API_KEY` লাগে। টেস্ট বিল্ডের জন্য এটা ছাড়াও APK তৈরি হবে,
কিন্তু AI ফিচার কাজ করবে না। আসল key দিয়ে বিল্ড করতে চাইলে:

1. রিপোর **Settings → Secrets and variables → Actions** এ যাও।
2. **New repository secret** চাপো।
3. Name: `GEMINI_API_KEY`, Value: তোমার আসল কী — সেভ করো।

ওয়ার্কফ্লো ফাইলটা এই সিক্রেট নিজে থেকেই ব্যবহার করবে, আলাদা কিছু করতে হবে না।

## ধাপ ৪: বিল্ড ট্রিগার করা

- Push করার সাথে সাথেই বিল্ড অটো-স্টার্ট হয়ে যাবে, অথবা
- রিপোর **Actions** ট্যাবে গিয়ে **Build Debug APK** ওয়ার্কফ্লো সিলেক্ট করে
  **Run workflow** বাটনে চাপো।

## ধাপ ৫: APK ডাউনলোড করা

1. **Actions** ট্যাবে গিয়ে সবচেয়ে নতুন রান-এ ক্লিক করো।
2. রান শেষ হলে (সবুজ টিক ✅) নিচে **Artifacts** সেকশনে
   `voice-generator-debug-apk` নামে একটা zip পাবে।
3. সেটা ডাউনলোড করে আনজিপ করলেই ভেতরে টেস্টিং এর জন্য APK পাবে —
   ফোনে ইন্সটল করে চালিয়ে দেখতে পারো।

---

## টেকনিক্যাল নোট (কেন এভাবে করা হলো)

- **`gradlew` ছিল না:** সাধারণত GitHub Actions এ `./gradlew assembleDebug` চালানো হয়,
  কিন্তু এই প্রজেক্টে wrapper ফাইল ছিল না। তাই `gradle/actions/setup-gradle@v4`
  অ্যাকশন দিয়ে সরাসরি **Gradle 9.1.1** ইনস্টল করে `gradle assembleDebug` চালানো হচ্ছে —
  এটা এই প্রজেক্টের AGP ভার্সন (`9.1.1`) এর জন্য প্রয়োজনীয় ন্যূনতম Gradle ভার্সন।
- **JDK 17:** AGP 9.x এর জন্য JDK 17+ বাধ্যতামূলক, তাই workflow এ সেটাই সেট করা আছে।
- **`debug.keystore` ছিল না:** `app/build.gradle.kts`-এ debug বিল্ডের জন্য
  `rootDir/debug.keystore` চাওয়া হয়েছে, কিন্তু ফাইলটা রিপোতে নেই (এবং থাকাও উচিত না,
  keystore গিটে রাখা ভালো প্র্যাকটিস না)। তাই বিল্ডের ঠিক আগে ওয়ার্কফ্লোতেই
  স্ট্যান্ডার্ড ডিবাগ কী (`keytool` দিয়ে) জেনারেট করে নেওয়া হচ্ছে।
- **Release বিল্ড এখানে নেই:** এই ওয়ার্কফ্লো শুধু টেস্টিং এর জন্য Debug APK বানায়।
  Play Store এ আপলোডের মতো signed Release বিল্ড দরকার হলে `KEYSTORE_PATH`,
  `STORE_PASSWORD`, `KEY_PASSWORD` — এই তিনটা secret যোগ করে আলাদা release workflow
  বানিয়ে দিতে পারি, চাইলে বলো।

---

কোনো স্টেপে বিল্ড ফেইল করলে **Actions** ট্যাবের লগ থেকে এরর মেসেজটা কপি করে
আমাকে পাঠিও — সাথে সাথে ঠিক করে দিচ্ছি।
