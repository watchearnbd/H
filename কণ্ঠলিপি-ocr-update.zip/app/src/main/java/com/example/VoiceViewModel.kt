package com.example

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

enum class StatusType { IDLE, PLAYING, DONE, ERROR }
enum class OcrStatus { IDLE, PROCESSING, DONE, ERROR }

class VoiceViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null

    val text           = MutableStateFlow("")
    val voices         = MutableStateFlow<List<Voice>>(emptyList())
    val selectedVoice  = MutableStateFlow<Voice?>(null)
    val rate           = MutableStateFlow(1.0f)
    val pitch          = MutableStateFlow(1.0f)
    val isSpeaking     = MutableStateFlow(false)
    val statusType     = MutableStateFlow(StatusType.IDLE)
    val statusMessage  = MutableStateFlow("")

    // OCR state
    val ocrStatus      = MutableStateFlow(OcrStatus.IDLE)
    val ocrText        = MutableStateFlow("")
    val copySuccess    = MutableStateFlow(false)

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    init { tts = TextToSpeech(application, this) }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val sorted = tts?.voices?.toList()
                ?.sortedByDescending { it.locale.language.startsWith("bn") }
                ?: emptyList()
            voices.value = sorted
            selectedVoice.value = sorted.firstOrNull()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?)  { statusType.value = StatusType.PLAYING; statusMessage.value = "বলছে..."; isSpeaking.value = true }
                override fun onDone(id: String?)   { statusType.value = StatusType.DONE;    statusMessage.value = "বলা শেষ ✓";  isSpeaking.value = false }
                @Deprecated("Deprecated") override fun onError(id: String?) { statusType.value = StatusType.ERROR; statusMessage.value = "সমস্যা হয়েছে"; isSpeaking.value = false }
                override fun onError(id: String?, code: Int) { statusType.value = StatusType.ERROR; statusMessage.value = "সমস্যা: $code"; isSpeaking.value = false }
            })
        }
    }

    fun updateText(v: String)        { text.value = v }
    fun selectVoice(v: Voice)        { selectedVoice.value = v }
    fun updateRate(v: Float)         { rate.value = v }
    fun updatePitch(v: Float)        { pitch.value = v }

    fun speak() {
        val t = text.value.trim()
        if (t.isEmpty()) { statusType.value = StatusType.ERROR; statusMessage.value = "প্রথমে কিছু লিখুন!"; return }
        tts?.stop()
        selectedVoice.value?.let { tts?.voice = it }
        tts?.setSpeechRate(rate.value)
        tts?.setPitch(pitch.value)
        val p = Bundle().also { it.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "UID") }
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, p, "UID")
    }

    fun stop() { tts?.stop(); statusType.value = StatusType.DONE; statusMessage.value = "থামানো হয়েছে"; isSpeaking.value = false }

    // ── OCR ──────────────────────────────────────────────
    fun recognizeImage(context: Context, uri: Uri) {
        viewModelScope.launch {
            ocrStatus.value = OcrStatus.PROCESSING
            ocrText.value   = ""
            try {
                val image  = InputImage.fromFilePath(context, uri)
                val result = recognizer.process(image).await()
                val found  = result.text.trim()
                if (found.isEmpty()) {
                    ocrStatus.value = OcrStatus.ERROR
                    ocrText.value   = "কোনো লেখা পাওয়া যায়নি"
                } else {
                    ocrText.value   = found
                    ocrStatus.value = OcrStatus.DONE
                }
            } catch (e: Exception) {
                ocrStatus.value = OcrStatus.ERROR
                ocrText.value   = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun copyOcrText(context: Context) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("OCR Text", ocrText.value))
        copySuccess.value = true
    }

    fun speakOcrText() {
        val t = ocrText.value.trim()
        if (t.isEmpty()) return
        tts?.stop()
        selectedVoice.value?.let { tts?.voice = it }
        tts?.setSpeechRate(rate.value)
        tts?.setPitch(pitch.value)
        val p = Bundle().also { it.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "OCR_UID") }
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, p, "OCR_UID")
    }

    fun resetCopySuccess() { copySuccess.value = false }
    fun clearOcr()         { ocrText.value = ""; ocrStatus.value = OcrStatus.IDLE }

    override fun onCleared() { tts?.stop(); tts?.shutdown(); super.onCleared() }
}
