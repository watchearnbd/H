package com.example

import android.net.Uri
import android.os.Bundle
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.ui.theme.MyApplicationTheme

val BgColor      = Color(0xFF0F1117)
val SurfaceColor = Color(0xFF1A1D27)
val BorderColor  = Color(0xFF2D3142)
val AccentColor  = Color(0xFF7C6FF7)
val Accent2Color = Color(0xFFA78BFA)
val TextColor    = Color(0xFFE8E9F0)
val MutedColor   = Color(0xFF94A3B8)
val LabelColor   = Color(0xFF6B7280)
val ErrorColor   = Color(0xFFF87171)
val SuccessColor = Color(0xFF34D399)
val AccentGradient = Brush.linearGradient(listOf(AccentColor, Accent2Color))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                Surface(modifier = Modifier.fillMaxSize(), color = BgColor) {
                    VoiceGeneratorScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceGeneratorScreen(vm: VoiceViewModel = viewModel()) {
    val context       = LocalContext.current
    val focusManager  = LocalFocusManager.current

    val text          by vm.text.collectAsState()
    val voices        by vm.voices.collectAsState()
    val selectedVoice by vm.selectedVoice.collectAsState()
    val rate          by vm.rate.collectAsState()
    val pitch         by vm.pitch.collectAsState()
    val isSpeaking    by vm.isSpeaking.collectAsState()
    val statusType    by vm.statusType.collectAsState()
    val statusMessage by vm.statusMessage.collectAsState()
    val ocrStatus     by vm.ocrStatus.collectAsState()
    val ocrText       by vm.ocrText.collectAsState()
    val copySuccess   by vm.copySuccess.collectAsState()

    // Tab state
    var selectedTab by remember { mutableStateOf(0) }

    // Image picker
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            pickedUri = it
            vm.recognizeImage(context, it)
        }
    }

    // Copy success snackbar
    LaunchedEffect(copySuccess) {
        if (copySuccess) {
            kotlinx.coroutines.delay(2000)
            vm.resetCopySuccess()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .systemBarsPadding()
    ) {
        // ── HEADER ──────────────────────────────────────
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(AccentGradient, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) { Text("🎙️", fontSize = 22.sp) }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("ভয়েস জেনারেটর", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("AI এর মাধ্যমে আপনার লেখা শুনুন", color = MutedColor, fontSize = 13.sp)
            }
        }

        // ── TABS ────────────────────────────────────────
        Row(
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .fillMaxWidth()
                .background(SurfaceColor, RoundedCornerShape(14.dp))
                .border(1.dp, BorderColor, RoundedCornerShape(14.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("✍️ লেখা থেকে", "📷 ছবি থেকে").forEachIndexed { i, label ->
                val sel = selectedTab == i
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (sel) AccentGradient else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { selectedTab = i }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = if (sel) Color.White else MutedColor, fontSize = 13.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── CONTENT ─────────────────────────────────────
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedTab == 0) {
                // ── TAB 1: লেখা থেকে ──────────────────
                TextTab(
                    text = text,
                    onTextChange = { vm.updateText(it) },
                    voices = voices,
                    selectedVoice = selectedVoice,
                    onVoiceSelect = { vm.selectVoice(it) },
                    rate = rate, onRateChange = { vm.updateRate(it) },
                    pitch = pitch, onPitchChange = { vm.updatePitch(it) },
                    statusType = statusType, statusMessage = statusMessage
                )
            } else {
                // ── TAB 2: ছবি থেকে ───────────────────
                ImageOcrTab(
                    pickedUri = pickedUri,
                    ocrStatus = ocrStatus,
                    ocrText = ocrText,
                    copySuccess = copySuccess,
                    onPickImage = { imagePicker.launch("image/*") },
                    onCopy = { vm.copyOcrText(context) },
                    onSpeak = { vm.speakOcrText() },
                    onClear = { pickedUri = null; vm.clearOcr() }
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        // ── FOOTER BUTTONS ──────────────────────────────
        if (selectedTab == 0) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { focusManager.clearFocus(); vm.speak() },
                    modifier = Modifier.weight(2f).height(54.dp),
                    enabled = !isSpeaking,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = AccentColor, disabledContainerColor = AccentColor.copy(.4f))
                ) {
                    Icon(Icons.Filled.PlayArrow, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("বলুন", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                OutlinedButton(
                    onClick = { vm.stop() },
                    modifier = Modifier.weight(1f).height(54.dp),
                    enabled = isSpeaking,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, BorderColor),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MutedColor, disabledContentColor = BorderColor)
                ) {
                    Icon(Icons.Filled.Stop, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("থামুন", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// TAB 1 — টেক্সট
// ─────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextTab(
    text: String, onTextChange: (String) -> Unit,
    voices: List<Voice>, selectedVoice: Voice?,
    onVoiceSelect: (Voice) -> Unit,
    rate: Float, onRateChange: (Float) -> Unit,
    pitch: Float, onPitchChange: (Float) -> Unit,
    statusType: StatusType, statusMessage: String
) {
    // Text area
    SectionLabel("আপনার লেখা")
    OutlinedTextField(
        value = text, onValueChange = onTextChange,
        placeholder = { Text("এখানে বাংলা বা ইংরেজি লেখুন...", color = MutedColor) },
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 180.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentColor, unfocusedBorderColor = BorderColor,
            focusedTextColor = TextColor, unfocusedTextColor = TextColor,
            focusedContainerColor = SurfaceColor, unfocusedContainerColor = SurfaceColor
        ),
        shape = RoundedCornerShape(16.dp)
    )
    Text("${text.length} অক্ষর", color = LabelColor, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().wrapContentWidth(Alignment.End))

    // Controls card
    Column(
        modifier = Modifier.fillMaxWidth()
            .background(SurfaceColor, RoundedCornerShape(18.dp))
            .border(1.dp, BorderColor, RoundedCornerShape(18.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Voice dropdown
        SectionLabel("ভয়েস নির্বাচন")
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
            OutlinedTextField(
                readOnly = true,
                value = selectedVoice?.let { "${if (it.locale.language.startsWith("bn")) "🇧🇩 " else ""}${it.name} (${it.locale.language})" } ?: "লোড হচ্ছে...",
                onValueChange = {},
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier.fillMaxWidth().menuAnchor(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AccentColor, unfocusedBorderColor = BorderColor,
                    focusedTextColor = TextColor, unfocusedTextColor = TextColor,
                    focusedContainerColor = BgColor, unfocusedContainerColor = BgColor
                ),
                shape = RoundedCornerShape(12.dp)
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.background(SurfaceColor)) {
                voices.forEach { v ->
                    DropdownMenuItem(
                        text = { Text("${if (v.locale.language.startsWith("bn")) "🇧🇩 " else ""}${v.name} (${v.locale.language})", color = TextColor) },
                        onClick = { onVoiceSelect(v); expanded = false }
                    )
                }
            }
        }

        // Rate & Pitch
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            SliderField("গতি", String.format("%.1f×", rate), rate, 0.5f..2f, onRateChange, Modifier.weight(1f))
            SliderField("পিচ", String.format("%.1f", pitch), pitch, 0f..2f, onPitchChange, Modifier.weight(1f))
        }
    }

    // Status
    if (statusType != StatusType.IDLE && statusMessage.isNotEmpty()) {
        StatusBar(statusType, statusMessage)
    }
}

// ─────────────────────────────────────────────────────────────────
// TAB 2 — ছবি OCR
// ─────────────────────────────────────────────────────────────────
@Composable
fun ImageOcrTab(
    pickedUri: Uri?,
    ocrStatus: OcrStatus,
    ocrText: String,
    copySuccess: Boolean,
    onPickImage: () -> Unit,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    onClear: () -> Unit
) {
    // Pick image button / preview
    if (pickedUri == null) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(SurfaceColor, RoundedCornerShape(18.dp))
                .border(2.dp, BorderColor, RoundedCornerShape(18.dp))
                .clickable { onPickImage() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("📷", fontSize = 40.sp)
                Text("ছবি বেছে নিন", color = AccentColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("গ্যালারি থেকে ছবি আপলোড করুন", color = MutedColor, fontSize = 12.sp)
            }
        }
    } else {
        // Image preview
        Box(modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(18.dp))) {
            AsyncImage(
                model = pickedUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Clear button
            Box(
                modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)
                    .size(32.dp)
                    .background(Color.Black.copy(.6f), CircleShape)
                    .clickable { onClear() },
                contentAlignment = Alignment.Center
            ) { Text("✕", color = Color.White, fontSize = 14.sp) }
        }

        Spacer(Modifier.height(4.dp))

        // OCR result
        when (ocrStatus) {
            OcrStatus.PROCESSING -> {
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .background(SurfaceColor, RoundedCornerShape(14.dp))
                        .border(1.dp, BorderColor, RoundedCornerShape(14.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(color = AccentColor, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text("ছবি থেকে লেখা পড়ছে...", color = MutedColor, fontSize = 13.sp)
                    }
                }
            }
            OcrStatus.DONE, OcrStatus.ERROR -> {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(SurfaceColor, RoundedCornerShape(16.dp))
                        .border(1.dp, if (ocrStatus == OcrStatus.ERROR) ErrorColor.copy(.3f) else BorderColor, RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (ocrStatus == OcrStatus.DONE) "📄 পাওয়া লেখা" else "⚠️ ত্রুটি",
                            color = if (ocrStatus == OcrStatus.DONE) Accent2Color else ErrorColor,
                            fontSize = 12.sp, fontWeight = FontWeight.Bold
                        )
                        if (ocrStatus == OcrStatus.DONE) {
                            Text("${ocrText.length} অক্ষর", color = LabelColor, fontSize = 11.sp)
                        }
                    }

                    Text(
                        ocrText,
                        color = if (ocrStatus == OcrStatus.DONE) TextColor else ErrorColor,
                        fontSize = 14.sp,
                        lineHeight = 22.sp
                    )

                    if (ocrStatus == OcrStatus.DONE) {
                        // Action buttons
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Copy button
                            Button(
                                onClick = onCopy,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (copySuccess) SuccessColor else SurfaceColor,
                                )
                            ) {
                                Icon(
                                    if (copySuccess) Icons.Filled.Check else Icons.Filled.ContentCopy,
                                    null, modifier = Modifier.size(15.dp),
                                    tint = if (copySuccess) Color.White else MutedColor
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    if (copySuccess) "কপি হয়েছে!" else "কপি করুন",
                                    color = if (copySuccess) Color.White else MutedColor,
                                    fontSize = 13.sp, fontWeight = FontWeight.Bold
                                )
                            }

                            // Speak button
                            Button(
                                onClick = onSpeak,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
                            ) {
                                Icon(Icons.Filled.VolumeUp, null, modifier = Modifier.size(15.dp), tint = Color.White)
                                Spacer(Modifier.width(6.dp))
                                Text("শুনুন", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Pick another image
                        TextButton(onClick = onPickImage, modifier = Modifier.fillMaxWidth()) {
                            Text("অন্য ছবি বেছে নিন", color = MutedColor, fontSize = 12.sp)
                        }
                    }
                }
            }
            else -> {}
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// Shared components
// ─────────────────────────────────────────────────────────────────
@Composable
fun SectionLabel(text: String) {
    Text(text, color = LabelColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp, modifier = Modifier.padding(start = 2.dp, bottom = 4.dp))
}

@Composable
fun SliderField(label: String, valText: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = LabelColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            Text(valText, color = Accent2Color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = AccentColor, activeTrackColor = AccentColor, inactiveTrackColor = BorderColor))
    }
}

@Composable
fun StatusBar(type: StatusType, message: String) {
    val (bg, border, tc) = when (type) {
        StatusType.PLAYING -> Triple(AccentColor.copy(.1f),  AccentColor.copy(.2f),  Accent2Color)
        StatusType.DONE    -> Triple(SuccessColor.copy(.1f), SuccessColor.copy(.2f), SuccessColor)
        StatusType.ERROR   -> Triple(ErrorColor.copy(.1f),   ErrorColor.copy(.2f),   ErrorColor)
        else               -> Triple(Color.Transparent, Color.Transparent, Color.Transparent)
    }
    Row(
        modifier = Modifier.fillMaxWidth()
            .background(bg, RoundedCornerShape(12.dp))
            .border(1.dp, border, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (type == StatusType.PLAYING) PulseDot(tc)
        else Box(Modifier.size(8.dp).background(tc, CircleShape))
        Text(message, color = tc, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PulseDot(color: Color) {
    val inf = rememberInfiniteTransition(label = "pulse")
    val alpha by inf.animateFloat(1f, 0.3f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "a")
    Box(Modifier.size(8.dp).alpha(alpha).background(color, CircleShape))
}
